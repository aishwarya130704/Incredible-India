"use client"

import { useState } from "react"
import { Train, Bus, Plane, Car, MapPin, CreditCard, Phone } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

const transportModes = [
  {
    id: "train",
    name: "Trains",
    icon: Train,
    description: "Extensive railway network connecting all major cities",
    color: "bg-blue-500",
  },
  {
    id: "bus",
    name: "Buses",
    icon: Bus,
    description: "State and private bus services for intercity travel",
    color: "bg-green-500",
  },
  {
    id: "flight",
    name: "Flights",
    icon: Plane,
    description: "Domestic airlines connecting major cities",
    color: "bg-purple-500",
  },
  {
    id: "local",
    name: "Local Transport",
    icon: Car,
    description: "Taxis, autos, and ride-sharing services",
    color: "bg-orange-500",
  },
]

const majorAirports = [
  { name: "Indira Gandhi International", city: "Delhi", code: "DEL" },
  { name: "Chhatrapati Shivaji Maharaj", city: "Mumbai", code: "BOM" },
  { name: "Kempegowda International", city: "Bangalore", code: "BLR" },
  { name: "Chennai International", city: "Chennai", code: "MAA" },
  { name: "Netaji Subhas Chandra Bose", city: "Kolkata", code: "CCU" },
  { name: "Rajiv Gandhi International", city: "Hyderabad", code: "HYD" },
]

const trainClasses = [
  { name: "AC First Class (1A)", description: "Premium comfort with private cabins" },
  { name: "AC 2-Tier (2A)", description: "Air-conditioned sleeper with curtains" },
  { name: "AC 3-Tier (3A)", description: "Most popular AC class" },
  { name: "Sleeper (SL)", description: "Non-AC sleeper, budget-friendly" },
  { name: "Second Sitting (2S)", description: "Reserved seating for day travel" },
]

export default function TransportPage() {
  const [activeTab, setActiveTab] = useState("train")

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-green-50 pt-20">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-gray-800 mb-4">Transport in India</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Navigate India with ease using our comprehensive guide to transportation options
          </p>
        </div>

        {/* Transport Mode Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          {transportModes.map((mode) => {
            const IconComponent = mode.icon
            return (
              <Card
                key={mode.id}
                className={`cursor-pointer transition-all duration-300 hover:shadow-lg transform hover:-translate-y-1 ${
                  activeTab === mode.id ? "ring-2 ring-orange-400 shadow-lg" : ""
                }`}
                onClick={() => setActiveTab(mode.id)}
              >
                <CardContent className="p-6 text-center">
                  <div className={`w-16 h-16 ${mode.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                    <IconComponent className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="font-bold text-lg mb-2">{mode.name}</h3>
                  <p className="text-sm text-gray-600">{mode.description}</p>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Detailed Information */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="train">Trains</TabsTrigger>
            <TabsTrigger value="bus">Buses</TabsTrigger>
            <TabsTrigger value="flight">Flights</TabsTrigger>
            <TabsTrigger value="local">Local Transport</TabsTrigger>
          </TabsList>

          <TabsContent value="train" className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Train className="h-5 w-5 mr-2 text-blue-500" />
                    Indian Railways Overview
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h4 className="font-semibold mb-2">Key Facts</h4>
                    <ul className="space-y-1 text-sm">
                      <li>• World's 4th largest railway network</li>
                      <li>• 68,000+ km of track length</li>
                      <li>• 7,000+ stations across India</li>
                      <li>• 23 million passengers daily</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Booking Tips</h4>
                    <ul className="space-y-1 text-sm text-gray-600">
                      <li>• Book through IRCTC website or app</li>
                      <li>• Advance booking opens 120 days prior</li>
                      <li>• Carry valid ID proof during travel</li>
                      <li>• Check PNR status before travel</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Train Classes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {trainClasses.map((trainClass, index) => (
                      <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                        <div>
                          <h5 className="font-medium">{trainClass.name}</h5>
                          <p className="text-sm text-gray-600">{trainClass.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Popular Train Routes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-gradient-to-r from-blue-100 to-blue-200 p-4 rounded-lg">
                    <h4 className="font-semibold">Golden Triangle</h4>
                    <p className="text-sm text-gray-700">Delhi → Agra → Jaipur</p>
                    <Badge className="mt-2 bg-blue-500">Popular</Badge>
                  </div>
                  <div className="bg-gradient-to-r from-green-100 to-green-200 p-4 rounded-lg">
                    <h4 className="font-semibold">Konkan Railway</h4>
                    <p className="text-sm text-gray-700">Mumbai → Goa → Mangalore</p>
                    <Badge className="mt-2 bg-green-500">Scenic</Badge>
                  </div>
                  <div className="bg-gradient-to-r from-purple-100 to-purple-200 p-4 rounded-lg">
                    <h4 className="font-semibold">Himalayan Queen</h4>
                    <p className="text-sm text-gray-700">Kalka → Shimla</p>
                    <Badge className="mt-2 bg-purple-500">Heritage</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="bus" className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Bus className="h-5 w-5 mr-2 text-green-500" />
                    Bus Travel in India
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-green-50 p-4 rounded-lg">
                    <h4 className="font-semibold mb-2">State Transport</h4>
                    <ul className="space-y-1 text-sm">
                      <li>• KSRTC (Karnataka)</li>
                      <li>• TNSTC (Tamil Nadu)</li>
                      <li>• MSRTC (Maharashtra)</li>
                      <li>• UPSRTC (Uttar Pradesh)</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Private Operators</h4>
                    <ul className="space-y-1 text-sm text-gray-600">
                      <li>• RedBus (Online booking platform)</li>
                      <li>• Volvo buses for luxury travel</li>
                      <li>• Sleeper buses for overnight journeys</li>
                      <li>• AC and Non-AC options available</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Bus Types & Amenities</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="border-l-4 border-green-500 pl-4">
                      <h5 className="font-medium">Volvo AC</h5>
                      <p className="text-sm text-gray-600">Premium comfort with AC, reclining seats</p>
                    </div>
                    <div className="border-l-4 border-blue-500 pl-4">
                      <h5 className="font-medium">Sleeper</h5>
                      <p className="text-sm text-gray-600">Overnight travel with sleeping berths</p>
                    </div>
                    <div className="border-l-4 border-orange-500 pl-4">
                      <h5 className="font-medium">Semi-Sleeper</h5>
                      <p className="text-sm text-gray-600">Reclining seats for comfortable travel</p>
                    </div>
                    <div className="border-l-4 border-gray-500 pl-4">
                      <h5 className="font-medium">Ordinary</h5>
                      <p className="text-sm text-gray-600">Budget-friendly option for short distances</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="flight" className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Plane className="h-5 w-5 mr-2 text-purple-500" />
                    Domestic Airlines
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-purple-50 p-3 rounded-lg text-center">
                      <h5 className="font-medium">IndiGo</h5>
                      <p className="text-xs text-gray-600">Largest market share</p>
                    </div>
                    <div className="bg-red-50 p-3 rounded-lg text-center">
                      <h5 className="font-medium">Air India</h5>
                      <p className="text-xs text-gray-600">National carrier</p>
                    </div>
                    <div className="bg-blue-50 p-3 rounded-lg text-center">
                      <h5 className="font-medium">SpiceJet</h5>
                      <p className="text-xs text-gray-600">Budget airline</p>
                    </div>
                    <div className="bg-green-50 p-3 rounded-lg text-center">
                      <h5 className="font-medium">Vistara</h5>
                      <p className="text-xs text-gray-600">Full-service</p>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Booking Tips</h4>
                    <ul className="space-y-1 text-sm text-gray-600">
                      <li>• Book in advance for better prices</li>
                      <li>• Check baggage allowance</li>
                      <li>• Arrive 2 hours before domestic flights</li>
                      <li>• Keep ID proof and boarding pass ready</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Major Airports</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {majorAirports.map((airport, index) => (
                      <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                        <div>
                          <h5 className="font-medium">{airport.name}</h5>
                          <p className="text-sm text-gray-600 flex items-center">
                            <MapPin className="h-3 w-3 mr-1" />
                            {airport.city}
                          </p>
                        </div>
                        <Badge variant="outline">{airport.code}</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="local" className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Car className="h-5 w-5 mr-2 text-orange-500" />
                    Ride-Sharing Services
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-black text-white p-4 rounded-lg text-center">
                      <h5 className="font-medium">Uber</h5>
                      <p className="text-xs opacity-80">Global ride-sharing</p>
                    </div>
                    <div className="bg-green-600 text-white p-4 rounded-lg text-center">
                      <h5 className="font-medium">Ola</h5>
                      <p className="text-xs opacity-80">Indian ride-sharing</p>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Service Types</h4>
                    <ul className="space-y-1 text-sm text-gray-600">
                      <li>• Micro/Mini - Budget option</li>
                      <li>• Prime/Sedan - Comfortable rides</li>
                      <li>• SUV - Group travel</li>
                      <li>• Auto - Traditional rickshaws</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Traditional Transport</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="border-l-4 border-yellow-500 pl-4">
                      <h5 className="font-medium">Auto Rickshaw</h5>
                      <p className="text-sm text-gray-600">3-wheeler, use meter or negotiate fare</p>
                    </div>
                    <div className="border-l-4 border-green-500 pl-4">
                      <h5 className="font-medium">Prepaid Taxi</h5>
                      <p className="text-sm text-gray-600">Available at airports and stations</p>
                    </div>
                    <div className="border-l-4 border-blue-500 pl-4">
                      <h5 className="font-medium">Metro</h5>
                      <p className="text-sm text-gray-600">Available in Delhi, Mumbai, Bangalore, etc.</p>
                    </div>
                    <div className="border-l-4 border-purple-500 pl-4">
                      <h5 className="font-medium">Local Buses</h5>
                      <p className="text-sm text-gray-600">Cheapest option for city travel</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Safety Tips</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center">
                      <Phone className="h-4 w-4 mr-2 text-orange-500" />
                      General Safety
                    </h4>
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li>• Share ride details with someone</li>
                      <li>• Check driver ratings and reviews</li>
                      <li>• Sit in the back seat</li>
                      <li>• Keep emergency contacts handy</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center">
                      <CreditCard className="h-4 w-4 mr-2 text-orange-500" />
                      Payment Tips
                    </h4>
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li>• Use digital payments when possible</li>
                      <li>• Keep small change for autos</li>
                      <li>• Negotiate fare before starting</li>
                      <li>• Ask for receipt in taxis</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
