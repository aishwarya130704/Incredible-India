"use client"

import { useState } from "react"
import { Phone, MapPin, Clock, AlertTriangle, Heart, Send } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"

const emergencyContacts = [
  {
    service: "Police",
    number: "100",
    description: "For any emergency requiring police assistance",
    icon: AlertTriangle,
    color: "bg-red-500",
  },
  {
    service: "Fire Brigade",
    number: "101",
    description: "Fire emergencies and rescue operations",
    icon: AlertTriangle,
    color: "bg-orange-500",
  },
  {
    service: "Ambulance",
    number: "102",
    description: "Medical emergencies and ambulance services",
    icon: Heart,
    color: "bg-green-500",
  },
  {
    service: "Tourist Helpline",
    number: "1363",
    description: "24/7 multilingual tourist assistance",
    icon: Phone,
    color: "bg-blue-500",
  },
]

const touristHelplines = [
  {
    state: "Delhi",
    number: "011-23315322",
    timings: "24/7",
    languages: ["Hindi", "English"],
  },
  {
    state: "Mumbai",
    number: "022-22074989",
    timings: "24/7",
    languages: ["Hindi", "English", "Marathi"],
  },
  {
    state: "Goa",
    number: "0832-2438751",
    timings: "9 AM - 6 PM",
    languages: ["English", "Hindi", "Konkani"],
  },
  {
    state: "Kerala",
    number: "0471-2321132",
    timings: "24/7",
    languages: ["English", "Hindi", "Malayalam"],
  },
  {
    state: "Rajasthan",
    number: "0141-2200999",
    timings: "24/7",
    languages: ["Hindi", "English"],
  },
  {
    state: "Tamil Nadu",
    number: "044-25361356",
    timings: "24/7",
    languages: ["English", "Hindi", "Tamil"],
  },
]

const importantNumbers = [
  { service: "Railway Enquiry", number: "139" },
  { service: "Airport Information", number: "Varies by airport" },
  { service: "Women Helpline", number: "1091" },
  { service: "Child Helpline", number: "1098" },
  { service: "Senior Citizen Helpline", number: "14567" },
  { service: "Disaster Management", number: "108" },
]

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  })

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    // Since this is frontend-only, we'll just show an alert
    alert("Thank you for your feedback! This is a demo form - no data is actually submitted.")
    setFormData({ name: "", email: "", subject: "", message: "" })
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-green-50 pt-20">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-gray-800 mb-4">Contact & Emergency Info</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Important contact numbers and emergency information for travelers in India
          </p>
        </div>

        {/* Emergency Contacts */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">Emergency Numbers</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {emergencyContacts.map((contact, index) => {
              const IconComponent = contact.icon
              return (
                <Card
                  key={index}
                  className="text-center hover:shadow-lg transition-all duration-300 border-0 bg-white/90 backdrop-blur-sm"
                >
                  <CardContent className="p-6">
                    <div
                      className={`w-16 h-16 ${contact.color} rounded-full flex items-center justify-center mx-auto mb-4`}
                    >
                      <IconComponent className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">{contact.service}</h3>
                    <div className="text-3xl font-bold text-gray-800 mb-3">{contact.number}</div>
                    <p className="text-sm text-gray-600">{contact.description}</p>
                  </CardContent>
                </Card>
              )
            })}
          </div>
          <div className="mt-6 p-4 bg-red-50 border border-red-200 rounded-lg">
            <div className="flex items-center mb-2">
              <AlertTriangle className="h-5 w-5 text-red-500 mr-2" />
              <h4 className="font-semibold text-red-700">Important Note</h4>
            </div>
            <p className="text-sm text-red-600">
              These are national emergency numbers. Always dial from any phone without area codes. Keep your location
              details ready when calling for help.
            </p>
          </div>
        </div>

        {/* Tourist Helplines */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">State Tourist Helplines</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {touristHelplines.map((helpline, index) => (
              <Card
                key={index}
                className="hover:shadow-lg transition-all duration-300 border-0 bg-white/90 backdrop-blur-sm"
              >
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{helpline.state}</span>
                    <Badge variant="outline" className="text-xs">
                      {helpline.timings}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center">
                      <Phone className="h-4 w-4 text-blue-500 mr-2" />
                      <span className="font-mono text-lg">{helpline.number}</span>
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 text-green-500 mr-2" />
                      <span className="text-sm text-gray-600">{helpline.timings}</span>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600 mb-2">Languages:</p>
                      <div className="flex flex-wrap gap-1">
                        {helpline.languages.map((lang, idx) => (
                          <Badge key={idx} variant="secondary" className="text-xs">
                            {lang}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Other Important Numbers */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">Other Important Numbers</h2>
          <Card className="border-0 bg-white/90 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {importantNumbers.map((item, index) => (
                  <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <span className="font-medium">{item.service}</span>
                    <span className="font-mono text-blue-600">{item.number}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Feedback Form */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">Send Us Feedback</h2>
          <Card className="max-w-2xl mx-auto border-0 bg-white/90 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-center">We'd Love to Hear From You</CardTitle>
              <p className="text-center text-gray-600">
                Share your travel experiences or suggestions to help us improve
              </p>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                      Name
                    </label>
                    <Input
                      id="name"
                      name="name"
                      type="text"
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder="Your full name"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                      Email
                    </label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="your.email@example.com"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-2">
                    Subject
                  </label>
                  <Input
                    id="subject"
                    name="subject"
                    type="text"
                    value={formData.subject}
                    onChange={handleInputChange}
                    placeholder="What is this about?"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                    Message
                  </label>
                  <Textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    placeholder="Tell us about your experience or suggestions..."
                    rows={5}
                    required
                  />
                </div>

                <Button type="submit" className="w-full bg-blue-500 hover:bg-blue-600">
                  <Send className="h-4 w-4 mr-2" />
                  Send Feedback
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Additional Information */}
        <Card className="border-0 bg-gradient-to-r from-blue-100 to-green-100">
          <CardHeader>
            <CardTitle className="text-center">Travel Safety Tips</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h4 className="font-semibold mb-4 flex items-center">
                  <Phone className="h-5 w-5 mr-2 text-blue-500" />
                  Communication Tips
                </h4>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li>• Save important numbers in your phone</li>
                  <li>• Keep a written copy of emergency contacts</li>
                  <li>• Learn basic Hindi phrases for emergencies</li>
                  <li>• Download offline translation apps</li>
                  <li>• Share your itinerary with family/friends</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-4 flex items-center">
                  <MapPin className="h-5 w-5 mr-2 text-green-500" />
                  Location & Documentation
                </h4>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li>• Always carry ID proof and copies</li>
                  <li>• Know your hotel address in local language</li>
                  <li>• Keep embassy contact information handy</li>
                  <li>• Register with your embassy if staying long-term</li>
                  <li>• Use GPS apps for navigation</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
