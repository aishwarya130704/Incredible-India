"use client"
import {
  ArrowLeft,
  Calendar,
  Clock,
  Star,
  Camera,
  Utensils,
  Car,
  Home,
  Phone,
  AlertTriangle,
  ArrowRight,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"
import { useParams } from "next/navigation"

const destinationGuides = {
  1: {
    name: "Delhi",
    region: "North India",
    image: "/images/delhi-red-fort.png",
    rating: 4.5,
    bestTime: "October to March",
    duration: "2-3 days",
    description:
      "India's vibrant capital city where ancient history meets modern life. Delhi offers an incredible journey through time with its magnificent Mughal monuments, bustling markets, and diverse culinary scene.",
    highlights: [
      "Explore the majestic Red Fort and its evening light show",
      "Visit India Gate and enjoy evening walks in the surrounding gardens",
      "Discover the towering Qutub Minar and its intricate architecture",
      "Experience the chaos and charm of Chandni Chowk market",
      "Marvel at the modern Lotus Temple and its unique design",
    ],
    attractions: [
      {
        name: "Red Fort (Lal Qila)",
        description: "UNESCO World Heritage site and symbol of India's rich history",
        timings: "9:30 AM - 4:30 PM (Closed on Mondays)",
        entryFee: "₹35 for Indians, ₹500 for foreigners",
        tips: "Visit during the evening light and sound show",
      },
      {
        name: "India Gate",
        description: "War memorial and popular picnic spot",
        timings: "24 hours",
        entryFee: "Free",
        tips: "Best visited during evening when it's beautifully lit",
      },
      {
        name: "Qutub Minar",
        description: "73-meter tall victory tower from the 12th century",
        timings: "7:00 AM - 5:00 PM",
        entryFee: "₹30 for Indians, ₹500 for foreigners",
        tips: "Early morning visits offer the best photography light",
      },
    ],
    itinerary: [
      {
        day: 1,
        title: "Old Delhi Exploration",
        activities: [
          "Morning: Visit Red Fort and explore its museums",
          "Afternoon: Walk through Chandni Chowk market",
          "Visit Jama Masjid, India's largest mosque",
          "Evening: Enjoy street food at Paranthe Wali Gali",
        ],
      },
      {
        day: 2,
        title: "New Delhi & Modern Attractions",
        activities: [
          "Morning: Visit India Gate and Rajpath",
          "Explore Humayun's Tomb and its gardens",
          "Afternoon: Visit Lotus Temple",
          "Evening: Shopping at Connaught Place",
        ],
      },
      {
        day: 3,
        title: "Cultural & Spiritual Delhi",
        activities: [
          "Morning: Visit Qutub Minar complex",
          "Explore Akshardham Temple",
          "Afternoon: Visit National Museum",
          "Evening: Sunset at Lodhi Gardens",
        ],
      },
    ],
    food: [
      {
        dish: "Chole Bhature",
        description: "Spicy chickpeas with fried bread",
        where: "Sita Ram Diwan Chand, Paharganj",
      },
      {
        dish: "Paranthe",
        description: "Stuffed flatbreads with various fillings",
        where: "Paranthe Wali Gali, Chandni Chowk",
      },
      {
        dish: "Kebabs",
        description: "Grilled meat delicacies",
        where: "Karim's, Jama Masjid",
      },
    ],
    accommodation: [
      {
        type: "Luxury",
        options: ["The Imperial", "Taj Palace", "Oberoi"],
        priceRange: "₹15,000 - ₹30,000 per night",
      },
      {
        type: "Mid-range",
        options: ["Hotel Tara Palace", "Bloom Hotel", "The Park"],
        priceRange: "₹3,000 - ₹8,000 per night",
      },
      {
        type: "Budget",
        options: ["Zostel Delhi", "Backpacker Panda", "Hotel Tara Palace"],
        priceRange: "₹500 - ₹2,000 per night",
      },
    ],
    transport: {
      airport: "Indira Gandhi International Airport (DEL) - 20km from city center",
      metro: "Extensive metro network covering most tourist areas",
      taxi: "Uber, Ola, and prepaid taxis available",
      autoRickshaw: "Negotiate fare or use app-based services",
    },
    tips: [
      "Carry water and stay hydrated, especially in summer",
      "Dress modestly when visiting religious sites",
      "Be cautious of pickpockets in crowded areas",
      "Try street food from busy stalls for safety",
      "Book metro cards for convenient travel",
    ],
  },
  2: {
    name: "Agra",
    region: "North India",
    image: "/images/agra-taj-mahal.png",
    rating: 4.8,
    bestTime: "October to March",
    duration: "1-2 days",
    description:
      "Home to the magnificent Taj Mahal, Agra is a city that epitomizes love and architectural brilliance. This former Mughal capital houses some of the world's most beautiful monuments.",
    highlights: [
      "Witness the breathtaking Taj Mahal at sunrise and sunset",
      "Explore the massive Agra Fort with its palaces and gardens",
      "Visit the abandoned city of Fatehpur Sikri",
      "Shop for marble inlay work and leather goods",
      "Experience Mughal cuisine and traditional sweets",
    ],
    attractions: [
      {
        name: "Taj Mahal",
        description: "UNESCO World Heritage site and symbol of eternal love",
        timings: "6:00 AM - 6:30 PM (Closed on Fridays)",
        entryFee: "₹50 for Indians, ₹1,100 for foreigners",
        tips: "Visit at sunrise for the most magical experience",
      },
      {
        name: "Agra Fort",
        description: "Massive red sandstone fort with beautiful palaces",
        timings: "6:00 AM - 6:00 PM",
        entryFee: "₹40 for Indians, ₹550 for foreigners",
        tips: "Allow 2-3 hours to explore the entire complex",
      },
      {
        name: "Fatehpur Sikri",
        description: "Abandoned Mughal city with stunning architecture",
        timings: "6:00 AM - 6:00 PM",
        entryFee: "₹40 for Indians, ₹550 for foreigners",
        tips: "Located 40km from Agra, plan a half-day trip",
      },
    ],
    itinerary: [
      {
        day: 1,
        title: "Taj Mahal & Agra Fort",
        activities: [
          "Early morning: Taj Mahal at sunrise",
          "Breakfast at hotel",
          "Morning: Explore Agra Fort",
          "Afternoon: Visit Mehtab Bagh for Taj views",
          "Evening: Shopping at Sadar Bazaar",
        ],
      },
      {
        day: 2,
        title: "Fatehpur Sikri & Local Culture",
        activities: [
          "Morning: Day trip to Fatehpur Sikri",
          "Explore Buland Darwaza and Jama Masjid",
          "Afternoon: Visit local marble workshops",
          "Evening: Sunset view of Taj Mahal",
        ],
      },
    ],
    food: [
      {
        dish: "Petha",
        description: "Traditional sweet made from ash gourd",
        where: "Panchhi Petha Store",
      },
      {
        dish: "Mughlai Cuisine",
        description: "Rich curries and biryanis",
        where: "Pinch of Spice, Dasaprakash",
      },
      {
        dish: "Bedai and Jalebi",
        description: "Traditional breakfast combination",
        where: "Deviram Sweets",
      },
    ],
    accommodation: [
      {
        type: "Luxury",
        options: ["Oberoi Amarvilas", "ITC Mughal", "Taj Hotel & Convention Centre"],
        priceRange: "₹20,000 - ₹50,000 per night",
      },
      {
        type: "Mid-range",
        options: ["Hotel Taj Resorts", "Crystal Sarovar Premiere", "Courtyard by Marriott"],
        priceRange: "₹4,000 - ₹12,000 per night",
      },
      {
        type: "Budget",
        options: ["Zostel Agra", "Hotel Kamal", "Shanti Lodge"],
        priceRange: "₹800 - ₹3,000 per night",
      },
    ],
    transport: {
      airport: "Agra Airport (AGR) - Limited flights, Delhi airport is better connected",
      train: "Agra Cantt and Agra Fort railway stations",
      taxi: "Taxis and auto-rickshaws available",
      bus: "Regular buses from Delhi (3-4 hours)",
    },
    tips: [
      "Book Taj Mahal tickets online in advance",
      "Carry valid ID proof for monument entry",
      "Avoid touts and unofficial guides",
      "Bargain while shopping for marble items",
      "Stay hydrated and wear comfortable shoes",
    ],
  },
  6: {
    name: "Goa",
    region: "South India",
    image: "/images/goa-beaches.png",
    rating: 4.4,
    bestTime: "November to February",
    duration: "3-4 days",
    description:
      "India's beach paradise with Portuguese heritage, vibrant nightlife, and laid-back coastal culture. Goa offers the perfect blend of relaxation, adventure, and cultural exploration.",
    highlights: [
      "Relax on pristine beaches like Baga, Calangute, and Palolem",
      "Explore Portuguese colonial architecture in Old Goa",
      "Experience vibrant nightlife and beach parties",
      "Enjoy water sports and dolphin watching",
      "Savor Goan cuisine with its unique Indo-Portuguese flavors",
    ],
    attractions: [
      {
        name: "Baga Beach",
        description: "Popular beach known for water sports and nightlife",
        timings: "24 hours",
        entryFee: "Free",
        tips: "Best for water sports and beach shacks",
      },
      {
        name: "Basilica of Bom Jesus",
        description: "UNESCO World Heritage site housing St. Francis Xavier's remains",
        timings: "9:00 AM - 6:30 PM",
        entryFee: "Free",
        tips: "Dress modestly and maintain silence inside",
      },
      {
        name: "Dudhsagar Falls",
        description: "Spectacular four-tiered waterfall in the Western Ghats",
        timings: "Best visited during monsoon (June-September)",
        entryFee: "₹30 entry to Bhagwan Mahavir Wildlife Sanctuary",
        tips: "Take a jeep safari or trek to reach the falls",
      },
    ],
    itinerary: [
      {
        day: 1,
        title: "North Goa Beaches",
        activities: [
          "Morning: Arrive and check into hotel",
          "Afternoon: Relax at Baga Beach",
          "Evening: Sunset at Anjuna Beach",
          "Night: Dinner at beach shack",
        ],
      },
      {
        day: 2,
        title: "Old Goa Heritage",
        activities: [
          "Morning: Visit Basilica of Bom Jesus",
          "Explore Se Cathedral",
          "Afternoon: Visit Reis Magos Fort",
          "Evening: Cruise on Mandovi River",
        ],
      },
      {
        day: 3,
        title: "South Goa & Adventure",
        activities: [
          "Morning: Visit Palolem Beach",
          "Afternoon: Water sports at Colva Beach",
          "Evening: Spice plantation tour",
          "Night: Beach party or casino",
        ],
      },
    ],
    food: [
      {
        dish: "Fish Curry Rice",
        description: "Goan staple with coconut-based curry",
        where: "Fisherman's Wharf, Souza Lobo",
      },
      {
        dish: "Bebinca",
        description: "Traditional Goan layered dessert",
        where: "Confeitaria 31 de Janeiro",
      },
      {
        dish: "Chorizo Pao",
        description: "Goan sausage bread",
        where: "Local bakeries and cafes",
      },
    ],
    accommodation: [
      {
        type: "Luxury",
        options: ["Taj Exotica", "Park Hyatt Goa", "Alila Diwa Goa"],
        priceRange: "₹15,000 - ₹40,000 per night",
      },
      {
        type: "Mid-range",
        options: ["Lemon Tree Hotel", "Novotel Goa", "Holiday Inn Resort"],
        priceRange: "₹4,000 - ₹12,000 per night",
      },
      {
        type: "Budget",
        options: ["Zostel Goa", "Backpacker Panda", "Beach huts"],
        priceRange: "₹800 - ₹3,000 per night",
      },
    ],
    transport: {
      airport: "Goa International Airport (GOI) - Dabolim",
      train: "Margao and Thivim railway stations",
      taxi: "Taxis, Uber, and Ola available",
      scooter: "Rent scooters for easy beach hopping",
    },
    tips: [
      "Rent a scooter for convenient transportation",
      "Try local feni (cashew liquor) responsibly",
      "Respect local customs and dress codes",
      "Bargain at flea markets like Anjuna",
      "Stay hydrated and use sunscreen",
    ],
  },
}

export default function DestinationGuidePage() {
  const params = useParams()
  const id = Number.parseInt(params.id as string)
  const guide = destinationGuides[id]

  if (!guide) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-orange-50 to-green-50 pt-20 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Destination Not Found</h1>
          <p className="text-xl text-gray-600 mb-8">The destination guide you're looking for doesn't exist.</p>
          <Link href="/destinations">
            <Button className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Destinations
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 to-green-50 pt-20">
      {/* Hero Section */}
      <div className="relative h-96 overflow-hidden">
        <img src={guide.image || "/placeholder.svg"} alt={guide.name} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-black/50" />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-6xl font-bold mb-4 drop-shadow-2xl">{guide.name}</h1>
            <p className="text-2xl mb-6 drop-shadow-lg">{guide.region}</p>
            <div className="flex items-center justify-center space-x-6 text-lg">
              <div className="flex items-center">
                <Star className="h-5 w-5 text-yellow-400 fill-current mr-2" />
                <span>{guide.rating}</span>
              </div>
              <div className="flex items-center">
                <Calendar className="h-5 w-5 mr-2" />
                <span>{guide.bestTime}</span>
              </div>
              <div className="flex items-center">
                <Clock className="h-5 w-5 mr-2" />
                <span>{guide.duration}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12">
        {/* Back Button */}
        <div className="mb-8">
          <Link href="/destinations">
            <Button
              variant="outline"
              className="hover:bg-orange-50 hover:text-orange-600 hover:border-orange-300 bg-transparent"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Destinations
            </Button>
          </Link>
        </div>

        {/* Overview */}
        <div className="mb-12">
          <Card className="border-0 bg-white/90 backdrop-blur-sm shadow-xl">
            <CardContent className="p-8">
              <h2 className="text-3xl font-bold text-gray-800 mb-6">About {guide.name}</h2>
              <p className="text-xl text-gray-600 leading-relaxed mb-8">{guide.description}</p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-2xl font-semibold text-gray-800 mb-4">Highlights</h3>
                  <ul className="space-y-3">
                    {guide.highlights.map((highlight, index) => (
                      <li key={index} className="flex items-start">
                        <Star className="h-5 w-5 text-orange-500 mr-3 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-600">{highlight}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-gradient-to-br from-orange-100 to-orange-200 p-6 rounded-2xl">
                  <h3 className="text-2xl font-semibold text-gray-800 mb-4">Quick Info</h3>
                  <div className="space-y-4">
                    <div className="flex items-center">
                      <Calendar className="h-5 w-5 text-orange-600 mr-3" />
                      <div>
                        <p className="font-medium">Best Time to Visit</p>
                        <p className="text-gray-600">{guide.bestTime}</p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-5 w-5 text-orange-600 mr-3" />
                      <div>
                        <p className="font-medium">Recommended Duration</p>
                        <p className="text-gray-600">{guide.duration}</p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <Star className="h-5 w-5 text-orange-600 mr-3" />
                      <div>
                        <p className="font-medium">Tourist Rating</p>
                        <p className="text-gray-600">{guide.rating}/5.0</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Guide Tabs */}
        <Tabs defaultValue="attractions" className="w-full">
          <TabsList className="grid w-full grid-cols-6 mb-8">
            <TabsTrigger value="attractions">Attractions</TabsTrigger>
            <TabsTrigger value="itinerary">Itinerary</TabsTrigger>
            <TabsTrigger value="food">Food</TabsTrigger>
            <TabsTrigger value="stay">Stay</TabsTrigger>
            <TabsTrigger value="transport">Transport</TabsTrigger>
            <TabsTrigger value="tips">Tips</TabsTrigger>
          </TabsList>

          <TabsContent value="attractions" className="space-y-6">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Top Attractions</h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {guide.attractions.map((attraction, index) => (
                <Card key={index} className="border-0 bg-white/90 backdrop-blur-sm shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Camera className="h-5 w-5 mr-2 text-orange-500" />
                      {attraction.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-gray-600">{attraction.description}</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="font-medium text-gray-800">Timings:</p>
                        <p className="text-gray-600">{attraction.timings}</p>
                      </div>
                      <div>
                        <p className="font-medium text-gray-800">Entry Fee:</p>
                        <p className="text-gray-600">{attraction.entryFee}</p>
                      </div>
                    </div>
                    <div className="bg-orange-50 p-3 rounded-lg">
                      <p className="text-sm text-orange-700">
                        <strong>Tip:</strong> {attraction.tips}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="itinerary" className="space-y-6">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Suggested Itinerary</h2>
            <div className="space-y-6">
              {guide.itinerary.map((day, index) => (
                <Card key={index} className="border-0 bg-white/90 backdrop-blur-sm shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <div className="w-8 h-8 bg-gradient-to-r from-orange-500 to-orange-600 text-white rounded-full flex items-center justify-center mr-3">
                        {day.day}
                      </div>
                      {day.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {day.activities.map((activity, idx) => (
                        <li key={idx} className="flex items-start">
                          <div className="w-2 h-2 bg-orange-400 rounded-full mr-3 mt-2 flex-shrink-0"></div>
                          <span className="text-gray-600">{activity}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="food" className="space-y-6">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Must-Try Food</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {guide.food.map((item, index) => (
                <Card key={index} className="border-0 bg-white/90 backdrop-blur-sm shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Utensils className="h-5 w-5 mr-2 text-orange-500" />
                      {item.dish}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-gray-600">{item.description}</p>
                    <div className="bg-green-50 p-3 rounded-lg">
                      <p className="text-sm text-green-700">
                        <strong>Where to try:</strong> {item.where}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="stay" className="space-y-6">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Accommodation Options</h2>
            <div className="space-y-6">
              {guide.accommodation.map((category, index) => (
                <Card key={index} className="border-0 bg-white/90 backdrop-blur-sm shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Home className="h-5 w-5 mr-2 text-orange-500" />
                      {category.type} Hotels
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-lg font-medium text-gray-800">{category.priceRange}</p>
                    <div className="flex flex-wrap gap-2">
                      {category.options.map((option, idx) => (
                        <Badge key={idx} variant="secondary" className="bg-blue-100 text-blue-700">
                          {option}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="transport" className="space-y-6">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Getting Around</h2>
            <Card className="border-0 bg-white/90 backdrop-blur-sm shadow-lg">
              <CardContent className="p-8 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-800 mb-3 flex items-center">
                      <Car className="h-5 w-5 mr-2 text-orange-500" />
                      Transportation Options
                    </h3>
                    <div className="space-y-3">
                      <div>
                        <p className="font-medium text-gray-800">Airport:</p>
                        <p className="text-gray-600">{guide.transport.airport}</p>
                      </div>
                      {guide.transport.train && (
                        <div>
                          <p className="font-medium text-gray-800">Railway:</p>
                          <p className="text-gray-600">{guide.transport.train}</p>
                        </div>
                      )}
                      {guide.transport.metro && (
                        <div>
                          <p className="font-medium text-gray-800">Metro:</p>
                          <p className="text-gray-600">{guide.transport.metro}</p>
                        </div>
                      )}
                      {guide.transport.bus && (
                        <div>
                          <p className="font-medium text-gray-800">Bus:</p>
                          <p className="text-gray-600">{guide.transport.bus}</p>
                        </div>
                      )}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-800 mb-3">Local Transport</h3>
                    <div className="space-y-3">
                      <div>
                        <p className="font-medium text-gray-800">Taxis:</p>
                        <p className="text-gray-600">{guide.transport.taxi}</p>
                      </div>
                      {guide.transport.autoRickshaw && (
                        <div>
                          <p className="font-medium text-gray-800">Auto Rickshaw:</p>
                          <p className="text-gray-600">{guide.transport.autoRickshaw}</p>
                        </div>
                      )}
                      {guide.transport.scooter && (
                        <div>
                          <p className="font-medium text-gray-800">Scooter Rental:</p>
                          <p className="text-gray-600">{guide.transport.scooter}</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tips" className="space-y-6">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Travel Tips</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="border-0 bg-white/90 backdrop-blur-sm shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <AlertTriangle className="h-5 w-5 mr-2 text-orange-500" />
                    Important Tips
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {guide.tips.map((tip, index) => (
                      <li key={index} className="flex items-start">
                        <div className="w-2 h-2 bg-orange-400 rounded-full mr-3 mt-2 flex-shrink-0"></div>
                        <span className="text-gray-600">{tip}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              <Card className="border-0 bg-gradient-to-br from-green-100 to-green-200 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Phone className="h-5 w-5 mr-2 text-green-600" />
                    Emergency Contacts
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <p className="font-medium text-gray-800">Police:</p>
                    <p className="text-gray-600">100</p>
                  </div>
                  <div>
                    <p className="font-medium text-gray-800">Tourist Helpline:</p>
                    <p className="text-gray-600">1363</p>
                  </div>
                  <div>
                    <p className="font-medium text-gray-800">Ambulance:</p>
                    <p className="text-gray-600">102</p>
                  </div>
                  <div>
                    <p className="font-medium text-gray-800">Fire:</p>
                    <p className="text-gray-600">101</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Related Destinations */}
        <div className="mt-16">
          <h2 className="text-3xl font-bold text-gray-800 mb-8">Explore More Destinations</h2>
          <div className="text-center">
            <Link href="/destinations">
              <Button
                size="lg"
                className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 px-8 py-4"
              >
                View All Destinations
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
