"use client"

import { useState, useEffect } from "react"
import { Search, Calendar, Star, Filter, ArrowRight, Clock, Users, MapPin, Thermometer } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { useSearchParams } from "next/navigation"

const destinations = [
  // North India
  {
    id: 1,
    name: "Delhi",
    region: "North",
    image: "/images/delhi-red-fort.png",
    bestTime: "Oct-Mar",
    attractions: ["Red Fort", "India Gate", "Qutub Minar", "Lotus Temple"],
    culture: "Mughal heritage, street food capital, political center",
    description: "India's vibrant capital city where ancient history meets modern life",
    rating: 4.5,
    duration: "2-3 days",
    temperature: "25°C",
    category: "Heritage",
    isPopular: true,
  },
  {
    id: 2,
    name: "Agra",
    region: "North",
    image: "/images/agra-taj-mahal.png",
    bestTime: "Oct-Mar",
    attractions: ["Taj Mahal", "Agra Fort", "Fatehpur Sikri", "Mehtab Bagh"],
    culture: "Mughal architecture, marble craftsmanship, love stories",
    description: "Home to the iconic Taj Mahal, symbol of eternal love",
    rating: 4.8,
    duration: "1-2 days",
    temperature: "28°C",
    category: "Heritage",
    isPopular: true,
  },
  {
    id: 3,
    name: "Jaipur",
    region: "North",
    image: "/images/jaipur-hawa-mahal.png",
    bestTime: "Oct-Mar",
    attractions: ["Hawa Mahal", "Amber Fort", "City Palace", "Jantar Mantar"],
    culture: "Rajput heritage, pink city architecture, royal traditions",
    description: "The Pink City known for its royal palaces and forts",
    rating: 4.6,
    duration: "2-3 days",
    temperature: "26°C",
    category: "Heritage",
    isPopular: true,
  },
  {
    id: 4,
    name: "Kashmir",
    region: "North",
    image: "/images/kashmir-dal-lake.png",
    bestTime: "Apr-Oct",
    attractions: ["Dal Lake", "Gulmarg", "Pahalgam", "Sonamarg"],
    culture: "Kashmiri handicrafts, houseboats, Sufi traditions",
    description: "Paradise on Earth with stunning valleys and lakes",
    rating: 4.9,
    duration: "4-5 days",
    temperature: "15°C",
    category: "Nature",
    isPopular: true,
  },
  {
    id: 15,
    name: "Varanasi",
    region: "North",
    image: "/images/varanasi-ghats.png",
    bestTime: "Oct-Mar",
    attractions: ["Dashashwamedh Ghat", "Kashi Vishwanath", "Sarnath", "Ganges Aarti"],
    culture: "Spiritual capital, ancient traditions, classical music",
    description: "One of the world's oldest cities, spiritual heart of India",
    rating: 4.7,
    duration: "2-3 days",
    temperature: "27°C",
    category: "Spiritual",
    isPopular: true,
  },
  {
    id: 16,
    name: "Rishikesh",
    region: "North",
    image: "/images/rishikesh-ganges.png",
    bestTime: "Sep-Apr",
    attractions: ["Laxman Jhula", "Ram Jhula", "Beatles Ashram", "Triveni Ghat"],
    culture: "Yoga capital, spiritual retreats, adventure sports",
    description: "World capital of yoga nestled in the Himalayan foothills",
    rating: 4.6,
    duration: "3-4 days",
    temperature: "22°C",
    category: "Spiritual",
    isPopular: false,
  },
  {
    id: 17,
    name: "Amritsar",
    region: "North",
    image: "/images/amritsar-golden-temple.png",
    bestTime: "Oct-Mar",
    attractions: ["Golden Temple", "Jallianwala Bagh", "Wagah Border", "Partition Museum"],
    culture: "Sikh heritage, langar tradition, Punjabi culture",
    description: "Holy city of Sikhs with the magnificent Golden Temple",
    rating: 4.8,
    duration: "2-3 days",
    temperature: "24°C",
    category: "Spiritual",
    isPopular: false,
  },
  {
    id: 18,
    name: "Ladakh",
    region: "North",
    image: "/images/ladakh-landscape.png",
    bestTime: "May-Sep",
    attractions: ["Leh Palace", "Pangong Lake", "Nubra Valley", "Magnetic Hill"],
    culture: "Buddhist monasteries, Tibetan culture, high altitude desert",
    description: "Land of high passes with breathtaking landscapes",
    rating: 4.9,
    duration: "5-7 days",
    temperature: "10°C",
    category: "Adventure",
    isPopular: true,
  },
  {
    id: 19,
    name: "Manali",
    region: "North",
    image: "/images/manali-mountains.png",
    bestTime: "Mar-Jun, Oct-Feb",
    attractions: ["Rohtang Pass", "Solang Valley", "Hadimba Temple", "Old Manali"],
    culture: "Himachali culture, adventure sports, apple orchards",
    description: "Popular hill station in Himachal Pradesh",
    rating: 4.5,
    duration: "3-4 days",
    temperature: "18°C",
    category: "Adventure",
    isPopular: true,
  },

  // South India
  {
    id: 5,
    name: "Kerala",
    region: "South",
    image: "/images/kerala-backwaters.png",
    bestTime: "Sep-Mar",
    attractions: ["Backwaters", "Munnar", "Kochi", "Thekkady"],
    culture: "Ayurveda, classical dance, spices, boat races",
    description: "God's Own Country with serene backwaters and hill stations",
    rating: 4.7,
    duration: "5-7 days",
    temperature: "29°C",
    category: "Nature",
    isPopular: true,
  },
  {
    id: 6,
    name: "Goa",
    region: "South",
    image: "/images/goa-beaches.png",
    bestTime: "Nov-Feb",
    attractions: ["Beaches", "Old Goa Churches", "Spice Plantations", "Dudhsagar Falls"],
    culture: "Portuguese influence, beach culture, carnival",
    description: "Tropical paradise with beautiful beaches and vibrant nightlife",
    rating: 4.4,
    duration: "3-4 days",
    temperature: "32°C",
    category: "Beach",
    isPopular: true,
  },
  {
    id: 7,
    name: "Mysore",
    region: "South",
    image: "/images/mysore-palace.png",
    bestTime: "Oct-Mar",
    attractions: ["Mysore Palace", "Chamundi Hills", "Brindavan Gardens", "St. Philomena's Church"],
    culture: "Royal heritage, silk sarees, sandalwood, classical music",
    description: "City of Palaces known for its royal heritage",
    rating: 4.5,
    duration: "2-3 days",
    temperature: "27°C",
    category: "Heritage",
    isPopular: false,
  },
  {
    id: 8,
    name: "Hampi",
    region: "South",
    image: "/images/hampi-ruins.png",
    bestTime: "Oct-Feb",
    attractions: ["Virupaksha Temple", "Vittala Temple", "Royal Enclosure", "Matanga Hill"],
    culture: "Vijayanagara empire ruins, ancient architecture, boulder landscape",
    description: "UNESCO World Heritage site with magnificent ruins",
    rating: 4.6,
    duration: "2-3 days",
    temperature: "30°C",
    category: "Heritage",
    isPopular: false,
  },
  {
    id: 20,
    name: "Ooty",
    region: "South",
    image: "/images/ooty-hills.png",
    bestTime: "Apr-Jun, Sep-Nov",
    attractions: ["Botanical Gardens", "Ooty Lake", "Toy Train", "Doddabetta Peak"],
    culture: "Colonial hill station, tea culture, Nilgiri tribes",
    description: "Queen of Hill Stations in the Nilgiri Mountains",
    rating: 4.4,
    duration: "2-3 days",
    temperature: "20°C",
    category: "Nature",
    isPopular: false,
  },
  {
    id: 21,
    name: "Coorg",
    region: "South",
    image: "/images/coorg-coffee-plantations.png",
    bestTime: "Oct-Mar",
    attractions: ["Coffee Plantations", "Abbey Falls", "Raja's Seat", "Dubare Elephant Camp"],
    culture: "Kodava culture, coffee heritage, warrior traditions",
    description: "Scotland of India famous for coffee plantations",
    rating: 4.5,
    duration: "2-3 days",
    temperature: "25°C",
    category: "Nature",
    isPopular: false,
  },
  {
    id: 22,
    name: "Andaman Islands",
    region: "South",
    image: "/images/andaman-beaches.png",
    bestTime: "Oct-May",
    attractions: ["Radhanagar Beach", "Cellular Jail", "Ross Island", "Baratang Island"],
    culture: "Tribal heritage, marine life, colonial history",
    description: "Pristine tropical islands with crystal clear waters",
    rating: 4.8,
    duration: "4-5 days",
    temperature: "30°C",
    category: "Beach",
    isPopular: true,
  },

  // East India
  {
    id: 9,
    name: "Kolkata",
    region: "East",
    image: "/images/kolkata-victoria-memorial.png",
    bestTime: "Oct-Mar",
    attractions: ["Victoria Memorial", "Howrah Bridge", "Dakshineswar Temple", "Park Street"],
    culture: "Bengali culture, literature, sweets, intellectual heritage",
    description: "Cultural capital of India with rich literary heritage",
    rating: 4.3,
    duration: "2-3 days",
    temperature: "28°C",
    category: "Heritage",
    isPopular: false,
  },
  {
    id: 10,
    name: "Darjeeling",
    region: "East",
    image: "/images/darjeeling-tea-gardens.png",
    bestTime: "Mar-May, Sep-Nov",
    attractions: ["Tiger Hill", "Tea Gardens", "Toy Train", "Batasia Loop"],
    culture: "Tea culture, Himalayan Buddhism, Gorkha heritage",
    description: "Queen of Hills famous for tea and mountain views",
    rating: 4.4,
    duration: "3-4 days",
    temperature: "18°C",
    category: "Nature",
    isPopular: false,
  },

  // West India
  {
    id: 11,
    name: "Mumbai",
    region: "West",
    image: "/images/mumbai-gateway.png",
    bestTime: "Nov-Feb",
    attractions: ["Gateway of India", "Marine Drive", "Elephanta Caves", "Bollywood Studios"],
    culture: "Bollywood, street food, business hub, cosmopolitan",
    description: "Financial capital and entertainment hub of India",
    rating: 4.2,
    duration: "2-3 days",
    temperature: "30°C",
    category: "Urban",
    isPopular: true,
  },
  {
    id: 12,
    name: "Udaipur",
    region: "West",
    image: "/images/udaipur-lake-palace.png",
    bestTime: "Sep-Mar",
    attractions: ["City Palace", "Lake Pichola", "Jag Mandir", "Saheliyon Ki Bari"],
    culture: "Rajput royalty, lake palaces, miniature paintings",
    description: "City of Lakes with romantic palaces and heritage",
    rating: 4.7,
    duration: "2-3 days",
    temperature: "25°C",
    category: "Heritage",
    isPopular: true,
  },
  {
    id: 23,
    name: "Pushkar",
    region: "West",
    image: "/images/pushkar-camel-fair.png",
    bestTime: "Oct-Mar",
    attractions: ["Pushkar Lake", "Brahma Temple", "Camel Fair", "Savitri Temple"],
    culture: "Rajasthani desert culture, camel trading, pilgrimage",
    description: "Holy city famous for its camel fair and sacred lake",
    rating: 4.3,
    duration: "2-3 days",
    temperature: "26°C",
    category: "Spiritual",
    isPopular: false,
  },
  {
    id: 24,
    name: "Khajuraho",
    region: "West",
    image: "/images/khajuraho-temples.png",
    bestTime: "Oct-Mar",
    attractions: ["Western Group Temples", "Eastern Group Temples", "Kandariya Mahadeva", "Light & Sound Show"],
    culture: "Medieval temple architecture, Chandela dynasty, erotic sculptures",
    description: "UNESCO site famous for intricately carved temples",
    rating: 4.5,
    duration: "1-2 days",
    temperature: "28°C",
    category: "Heritage",
    isPopular: false,
  },

  // North-East India
  {
    id: 13,
    name: "Shillong",
    region: "North-East",
    image: "/images/shillong-waterfalls.png",
    bestTime: "Sep-May",
    attractions: ["Elephant Falls", "Shillong Peak", "Ward's Lake", "Don Bosco Museum"],
    culture: "Khasi culture, music, natural beauty, Christian heritage",
    description: "Scotland of the East with rolling hills and waterfalls",
    rating: 4.3,
    duration: "3-4 days",
    temperature: "20°C",
    category: "Nature",
    isPopular: false,
  },
  {
    id: 14,
    name: "Kaziranga",
    region: "North-East",
    image: "/images/kaziranga-rhino.png",
    bestTime: "Nov-Apr",
    attractions: ["One-horned Rhino", "Elephant Safari", "Bird Watching", "Jeep Safari"],
    culture: "Assamese culture, wildlife conservation, tea gardens",
    description: "UNESCO World Heritage site famous for one-horned rhinoceros",
    rating: 4.5,
    duration: "2-3 days",
    temperature: "24°C",
    category: "Wildlife",
    isPopular: false,
  },
]

const regions = ["All", "North", "South", "East", "West", "North-East"]
const categories = ["All", "Heritage", "Nature", "Beach", "Spiritual", "Adventure", "Urban", "Wildlife"]

export default function DestinationsPage() {
  const [selectedRegion, setSelectedRegion] = useState("All")
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [searchQuery, setSearchQuery] = useState("")
  const [sortBy, setSortBy] = useState("popular")
  const searchParams = useSearchParams()

  useEffect(() => {
    const searchParam = searchParams.get("search")
    if (searchParam) {
      setSearchQuery(searchParam)
    }
  }, [searchParams])

  const filteredDestinations = destinations
    .filter((destination) => {
      const matchesRegion = selectedRegion === "All" || destination.region === selectedRegion
      const matchesCategory = selectedCategory === "All" || destination.category === selectedCategory
      const matchesSearch =
        searchQuery === "" ||
        destination.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        destination.culture.toLowerCase().includes(searchQuery.toLowerCase()) ||
        destination.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        destination.attractions.some((attraction) => attraction.toLowerCase().includes(searchQuery.toLowerCase()))
      return matchesRegion && matchesCategory && matchesSearch
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "rating":
          return b.rating - a.rating
        case "name":
          return a.name.localeCompare(b.name)
        case "popular":
        default:
          return b.isPopular - a.isPopular || b.rating - a.rating
      }
    })

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 to-green-50 pt-20">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-6xl font-bold text-gray-800 mb-6 bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
            Explore Destinations
          </h1>
          <p className="text-2xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Discover India's incredible diversity through {destinations.length}+ magnificent destinations, each offering
            unique experiences and cultural treasures waiting to be explored
          </p>
        </div>

        {/* Enhanced Search and Filter */}
        <div className="mb-16 space-y-6">
          {/* Search Bar */}
          <div className="flex justify-center">
            <div className="flex w-full max-w-2xl bg-white rounded-full p-3 shadow-xl border border-orange-100">
              <Input
                type="text"
                placeholder="Search destinations, attractions, culture, experiences..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="border-0 bg-transparent text-lg"
              />
              <Button
                size="sm"
                className="rounded-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 px-6"
              >
                <Search className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Filters */}
          <div className="flex flex-col lg:flex-row gap-6 items-center justify-between">
            {/* Region Filter */}
            <div className="flex gap-2 flex-wrap justify-center">
              <span className="text-sm font-medium text-gray-600 mr-2 flex items-center">
                <MapPin className="h-4 w-4 mr-1" />
                Region:
              </span>
              {regions.map((region) => (
                <Button
                  key={region}
                  variant={selectedRegion === region ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedRegion(region)}
                  className={
                    selectedRegion === region
                      ? "bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white"
                      : "hover:bg-orange-50 hover:text-orange-600 hover:border-orange-300"
                  }
                >
                  {region}
                </Button>
              ))}
            </div>

            {/* Category Filter */}
            <div className="flex gap-2 flex-wrap justify-center">
              <span className="text-sm font-medium text-gray-600 mr-2 flex items-center">
                <Filter className="h-4 w-4 mr-1" />
                Type:
              </span>
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className={
                    selectedCategory === category
                      ? "bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white"
                      : "hover:bg-green-50 hover:text-green-600 hover:border-green-300"
                  }
                >
                  {category}
                </Button>
              ))}
            </div>

            {/* Sort Options */}
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-gray-600">Sort by:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg bg-white text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
              >
                <option value="popular">Popular</option>
                <option value="rating">Rating</option>
                <option value="name">Name</option>
              </select>
            </div>
          </div>
        </div>

        {/* Results Count and Stats */}
        <div className="mb-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-xl text-gray-600 mb-4 md:mb-0">
            Showing <span className="font-semibold text-orange-600">{filteredDestinations.length}</span> destination
            {filteredDestinations.length !== 1 ? "s" : ""}
            {selectedRegion !== "All" && ` in ${selectedRegion} India`}
            {selectedCategory !== "All" && ` in ${selectedCategory} category`}
            {searchQuery && ` matching "${searchQuery}"`}
          </p>

          <div className="flex gap-4 text-sm text-gray-500">
            <span>🏛️ {destinations.filter((d) => d.category === "Heritage").length} Heritage</span>
            <span>🏔️ {destinations.filter((d) => d.category === "Nature").length} Nature</span>
            <span>🏖️ {destinations.filter((d) => d.category === "Beach").length} Beach</span>
            <span>🕉️ {destinations.filter((d) => d.category === "Spiritual").length} Spiritual</span>
          </div>
        </div>

        {/* Destinations Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {filteredDestinations.map((destination) => (
            <Link key={destination.id} href={`/destinations/${destination.id}`}>
              <Card className="group hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-3 border-0 bg-white/95 backdrop-blur-sm overflow-hidden cursor-pointer h-full">
                <div className="relative overflow-hidden">
                  <img
                    src={destination.image || "/placeholder.svg"}
                    alt={destination.name}
                    className="w-full h-56 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />

                  {/* Badges */}
                  <div className="absolute top-4 left-4 flex flex-col gap-2">
                    <Badge className="bg-gradient-to-r from-orange-500 to-orange-600 text-white px-3 py-1 text-xs">
                      {destination.region}
                    </Badge>
                    <Badge className="bg-gradient-to-r from-green-500 to-green-600 text-white px-3 py-1 text-xs">
                      {destination.category}
                    </Badge>
                    {destination.isPopular && (
                      <Badge className="bg-gradient-to-r from-red-500 to-red-600 text-white px-3 py-1 text-xs">
                        Popular
                      </Badge>
                    )}
                  </div>

                  {/* Rating and Temperature */}
                  <div className="absolute top-4 right-4 flex flex-col gap-2">
                    <div className="bg-white/90 backdrop-blur-sm rounded-full px-3 py-1 flex items-center">
                      <Star className="h-4 w-4 text-yellow-500 fill-current mr-1" />
                      <span className="text-sm font-medium">{destination.rating}</span>
                    </div>
                    <div className="bg-white/90 backdrop-blur-sm rounded-full px-3 py-1 flex items-center">
                      <Thermometer className="h-4 w-4 text-blue-500 mr-1" />
                      <span className="text-sm font-medium">{destination.temperature}</span>
                    </div>
                  </div>

                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="text-white text-2xl font-bold mb-2 drop-shadow-lg">{destination.name}</h3>
                    <div className="flex items-center text-white/90 text-sm mb-2">
                      <Calendar className="h-4 w-4 mr-2" />
                      Best: {destination.bestTime}
                      <Clock className="h-4 w-4 ml-4 mr-2" />
                      {destination.duration}
                    </div>
                  </div>
                </div>

                <CardContent className="p-6 flex-1 flex flex-col">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center">
                      <Users className="h-4 w-4 text-orange-500 mr-2" />
                      <span className="text-sm text-gray-600">{destination.attractions.length} attractions</span>
                    </div>
                    <ArrowRight className="h-5 w-5 text-orange-500 group-hover:translate-x-1 transition-transform" />
                  </div>

                  <p className="text-gray-600 mb-4 text-sm leading-relaxed flex-1">{destination.description}</p>

                  <div className="mb-4">
                    <h4 className="font-semibold text-gray-800 mb-2 flex items-center text-sm">
                      <Star className="h-4 w-4 mr-2 text-orange-500" />
                      Top Attractions
                    </h4>
                    <div className="flex flex-wrap gap-1">
                      {destination.attractions.slice(0, 3).map((attraction, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs bg-green-100 text-green-700 px-2 py-1">
                          {attraction}
                        </Badge>
                      ))}
                      {destination.attractions.length > 3 && (
                        <Badge variant="secondary" className="text-xs bg-gray-100 text-gray-600 px-2 py-1">
                          +{destination.attractions.length - 3} more
                        </Badge>
                      )}
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <h4 className="font-semibold text-gray-800 mb-2 flex items-center text-sm">
                      <MapPin className="h-4 w-4 mr-2 text-orange-500" />
                      Culture Highlights
                    </h4>
                    <p className="text-gray-600 text-sm line-clamp-2">{destination.culture}</p>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {/* No Results */}
        {filteredDestinations.length === 0 && (
          <div className="text-center py-20">
            <div className="w-32 h-32 bg-gradient-to-br from-orange-200 to-orange-300 rounded-full flex items-center justify-center mx-auto mb-8">
              <Search className="h-16 w-16 text-orange-600" />
            </div>
            <h3 className="text-3xl font-semibold text-gray-600 mb-4">No destinations found</h3>
            <p className="text-xl text-gray-500 mb-8">
              Try adjusting your search criteria or explore different regions and categories
            </p>
            <div className="flex gap-4 justify-center">
              <Button
                onClick={() => {
                  setSearchQuery("")
                  setSelectedRegion("All")
                  setSelectedCategory("All")
                }}
                className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700"
              >
                Clear All Filters
              </Button>
              <Button
                variant="outline"
                onClick={() => setSelectedCategory("Popular")}
                className="hover:bg-orange-50 hover:text-orange-600 hover:border-orange-300"
              >
                Show Popular Destinations
              </Button>
            </div>
          </div>
        )}

        {/* Quick Stats */}
        <div className="mt-16 bg-gradient-to-r from-orange-100 via-yellow-50 to-green-100 rounded-3xl p-8">
          <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">Explore by Numbers</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div>
              <div className="text-4xl font-bold text-orange-600 mb-2">{destinations.length}</div>
              <div className="text-gray-600">Total Destinations</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-green-600 mb-2">
                {destinations.filter((d) => d.isPopular).length}
              </div>
              <div className="text-gray-600">Popular Spots</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-blue-600 mb-2">{categories.length - 1}</div>
              <div className="text-gray-600">Categories</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-purple-600 mb-2">{regions.length - 1}</div>
              <div className="text-gray-600">Regions</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
