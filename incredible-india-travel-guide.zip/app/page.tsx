"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Search, MapPin, Calendar, Users, Star, ArrowRight, Camera, Compass } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { useRouter } from "next/navigation"

const heroImages = [
  "/images/hero-taj-mahal.png",
  "/images/hero-kerala-backwaters.png",
  "/images/hero-rajasthan-palace.png",
  "/images/hero-himalayas.png",
  "/images/hero-goa-beach.png",
]

const heroTitles = [
  "Taj Mahal - Symbol of Love",
  "Kerala Backwaters - God's Own Country",
  "Rajasthan Palaces - Royal Heritage",
  "Himalayan Peaks - Roof of the World",
  "Goa Beaches - Tropical Paradise",
]

const featuredDestinations = [
  {
    id: 6,
    name: "Goa",
    image: "/images/goa-beaches.png",
    description: "Sun, sand, and Portuguese heritage",
    highlights: ["Beaches", "Nightlife", "Churches"],
    category: "Beach",
  },
  {
    id: 1,
    name: "Delhi",
    image: "/images/delhi-red-fort.png",
    description: "Capital city with rich Mughal history",
    highlights: ["Red Fort", "India Gate", "Street Food"],
    category: "Heritage",
  },
  {
    id: 4,
    name: "Kashmir",
    image: "/images/kashmir-dal-lake.png",
    description: "Paradise on Earth with stunning valleys",
    highlights: ["Dal Lake", "Houseboats", "Saffron Fields"],
    category: "Nature",
  },
  {
    id: 5,
    name: "Kerala",
    image: "/images/kerala-backwaters.png",
    description: "God's Own Country with backwaters",
    highlights: ["Backwaters", "Ayurveda", "Spice Gardens"],
    category: "Nature",
  },
  {
    id: 15,
    name: "Varanasi",
    image: "/images/varanasi-ghats.png",
    description: "Spiritual capital of India",
    highlights: ["Ganges Ghats", "Ancient Temples", "Spiritual Rituals"],
    category: "Spiritual",
  },
  {
    id: 18,
    name: "Ladakh",
    image: "/images/ladakh-landscape.png",
    description: "Land of high passes",
    highlights: ["Pangong Lake", "Monasteries", "Adventure"],
    category: "Adventure",
  },
]

const experienceCategories = [
  {
    title: "Heritage & Culture",
    description: "Explore ancient monuments and rich traditions",
    image: "/images/agra-taj-mahal.png",
    count: "15+ UNESCO Sites",
    destinations: ["Delhi", "Agra", "Jaipur", "Hampi"],
  },
  {
    title: "Adventure & Nature",
    description: "Trek mountains, explore wildlife, and pristine landscapes",
    image: "/images/ladakh-landscape.png",
    count: "10+ Adventure Spots",
    destinations: ["Ladakh", "Manali", "Rishikesh", "Kaziranga"],
  },
  {
    title: "Spiritual Journey",
    description: "Visit sacred temples and spiritual centers",
    image: "/images/varanasi-ghats.png",
    count: "8+ Holy Cities",
    destinations: ["Varanasi", "Rishikesh", "Amritsar", "Pushkar"],
  },
  {
    title: "Beach Paradise",
    description: "Relax on pristine beaches and coastal beauty",
    image: "/images/goa-beaches.png",
    count: "5+ Beach Destinations",
    destinations: ["Goa", "Andaman", "Kerala Beaches"],
  },
]

const topAttractions = [
  { name: "Taj Mahal", location: "Agra", rating: 4.9, image: "/images/agra-taj-mahal.png" },
  { name: "Golden Temple", location: "Amritsar", rating: 4.8, image: "/images/amritsar-golden-temple.png" },
  { name: "Hawa Mahal", location: "Jaipur", rating: 4.7, image: "/images/jaipur-hawa-mahal.png" },
  { name: "Gateway of India", location: "Mumbai", rating: 4.6, image: "/images/mumbai-gateway.png" },
  { name: "Mysore Palace", location: "Mysore", rating: 4.8, image: "/images/mysore-palace.png" },
]

const quickSearchSuggestions = [
  "Delhi",
  "Mumbai",
  "Goa",
  "Kerala",
  "Rajasthan",
  "Kashmir",
  "Agra",
  "Jaipur",
  "Varanasi",
  "Ladakh",
  "Manali",
  "Rishikesh",
]

export default function HomePage() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const [searchQuery, setSearchQuery] = useState("")
  const [showSuggestions, setShowSuggestions] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroImages.length)
    }, 6000)
    return () => clearInterval(timer)
  }, [])

  const handleSearch = () => {
    if (searchQuery.trim()) {
      router.push(`/destinations?search=${encodeURIComponent(searchQuery.trim())}`)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSearch()
    }
  }

  const handleSuggestionClick = (suggestion: string) => {
    setSearchQuery(suggestion)
    setShowSuggestions(false)
    router.push(`/destinations?search=${encodeURIComponent(suggestion)}`)
  }

  const filteredSuggestions = quickSearchSuggestions.filter((suggestion) =>
    suggestion.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 to-green-50">
      {/* Enhanced Hero Section */}
      <section className="relative h-screen overflow-hidden">
        <div className="absolute inset-0">
          {heroImages.map((image, index) => (
            <div
              key={index}
              className={`absolute inset-0 transition-all duration-1000 ${
                index === currentSlide ? "opacity-100 scale-100" : "opacity-0 scale-105"
              }`}
            >
              <img src={image || "/placeholder.svg"} alt={heroTitles[index]} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-black/50" />
            </div>
          ))}
        </div>

        <div className="relative z-10 flex flex-col items-center justify-center h-full text-white text-center px-4">
          <div className="mb-8">
            <h1 className="text-6xl md:text-8xl font-bold mb-6 animate-fade-in bg-gradient-to-r from-orange-300 via-yellow-300 to-green-300 bg-clip-text text-transparent drop-shadow-2xl">
              Incredible India
            </h1>
            <p className="text-2xl md:text-3xl mb-4 font-light tracking-wide drop-shadow-lg">
              {heroTitles[currentSlide]}
            </p>
            <p className="text-lg md:text-xl mb-8 max-w-3xl opacity-90 drop-shadow">
              Your Ultimate Travel Companion to Explore the Land of Diversity
            </p>
          </div>

          {/* Enhanced Search Bar */}
          <div className="relative w-full max-w-2xl mb-8">
            <div className="flex bg-white/95 backdrop-blur-md rounded-full p-4 shadow-2xl border border-white/20">
              <Search className="h-6 w-6 text-gray-400 mr-3 mt-1" />
              <Input
                type="text"
                placeholder="Search destinations, attractions, experiences..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value)
                  setShowSuggestions(e.target.value.length > 0)
                }}
                onKeyPress={handleKeyPress}
                onFocus={() => setShowSuggestions(searchQuery.length > 0)}
                className="border-0 bg-transparent text-gray-800 placeholder-gray-500 text-lg flex-1"
              />
              <Button
                onClick={handleSearch}
                size="lg"
                className="rounded-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 px-8 ml-2"
              >
                Explore
              </Button>
            </div>

            {/* Enhanced Search Suggestions */}
            {showSuggestions && filteredSuggestions.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-white/95 backdrop-blur-md rounded-2xl shadow-2xl border border-white/20 overflow-hidden max-h-80 overflow-y-auto">
                <div className="p-2">
                  <div className="text-sm text-gray-500 px-4 py-2 font-medium">Popular Destinations</div>
                  {filteredSuggestions.map((suggestion, index) => (
                    <button
                      key={index}
                      onClick={() => handleSuggestionClick(suggestion)}
                      className="w-full px-4 py-3 text-left text-gray-700 hover:bg-orange-50 transition-colors rounded-lg flex items-center"
                    >
                      <Compass className="h-4 w-4 mr-3 text-orange-500" />
                      <span className="font-medium">{suggestion}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/destinations">
              <Button
                size="lg"
                className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white px-10 py-4 text-lg rounded-full shadow-2xl transform hover:scale-105 transition-all"
              >
                <Camera className="mr-2 h-5 w-5" />
                Explore Destinations
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="/plan-trip">
              <Button
                size="lg"
                variant="outline"
                className="bg-white/20 backdrop-blur-md border-2 border-white/50 text-white hover:bg-white/30 px-10 py-4 text-lg rounded-full shadow-2xl transform hover:scale-105 transition-all"
              >
                <MapPin className="mr-2 h-5 w-5" />
                Plan Your Trip
              </Button>
            </Link>
          </div>
        </div>

        {/* Enhanced Slide Indicators */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-4">
          {heroImages.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`transition-all duration-300 ${
                index === currentSlide
                  ? "w-12 h-4 bg-white rounded-full shadow-lg"
                  : "w-4 h-4 bg-white/50 rounded-full hover:bg-white/75"
              }`}
            />
          ))}
        </div>
      </section>

      {/* Experience Categories */}
      <section className="py-24 px-4 bg-gradient-to-r from-orange-100 via-yellow-50 to-green-100">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <h2 className="text-5xl font-bold text-gray-800 mb-6">Discover India Your Way</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              From ancient heritage to modern adventures, India offers experiences for every type of traveler
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {experienceCategories.map((category, index) => (
              <Card
                key={index}
                className="group hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-4 border-0 bg-white/90 backdrop-blur-sm overflow-hidden cursor-pointer"
              >
                <div className="relative h-56 overflow-hidden">
                  <img
                    src={category.image || "/placeholder.svg"}
                    alt={category.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4 text-white">
                    <Badge className="bg-orange-500 text-white mb-2 text-xs">{category.count}</Badge>
                    <h3 className="text-xl font-bold mb-2 drop-shadow-lg">{category.title}</h3>
                  </div>
                </div>
                <CardContent className="p-6">
                  <p className="text-gray-600 leading-relaxed mb-4">{category.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {category.destinations.slice(0, 3).map((dest, idx) => (
                      <Badge key={idx} variant="secondary" className="text-xs bg-green-100 text-green-700">
                        {dest}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Destinations */}
      <section className="py-24 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <h2 className="text-5xl font-bold text-gray-800 mb-6">Featured Destinations</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Discover the most popular destinations that showcase India's incredible diversity and rich cultural
              heritage
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6">
            {featuredDestinations.map((destination, index) => (
              <Link key={index} href={`/destinations/${destination.id}`}>
                <Card className="group hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-3 border-0 bg-white/90 backdrop-blur-sm overflow-hidden cursor-pointer h-full">
                  <div className="relative overflow-hidden">
                    <img
                      src={destination.image || "/placeholder.svg"}
                      alt={destination.name}
                      className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                    <div className="absolute top-3 right-3">
                      <Badge className="bg-gradient-to-r from-green-500 to-green-600 text-white text-xs px-2 py-1">
                        {destination.category}
                      </Badge>
                    </div>
                    <div className="absolute bottom-3 left-3 right-3">
                      <h3 className="text-white text-lg font-bold mb-1 drop-shadow-lg">{destination.name}</h3>
                      <p className="text-white/90 text-sm drop-shadow">{destination.description}</p>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex flex-wrap gap-1">
                      {destination.highlights.slice(0, 2).map((highlight, idx) => (
                        <Badge
                          key={idx}
                          variant="secondary"
                          className="text-xs bg-orange-100 text-orange-700 px-2 py-1"
                        >
                          {highlight}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link href="/destinations">
              <Button
                size="lg"
                className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 px-8 py-4 text-lg rounded-full"
              >
                View All {featuredDestinations.length * 4}+ Destinations
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Top Attractions */}
      <section className="py-24 px-4 bg-gradient-to-r from-blue-50 via-purple-50 to-pink-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <h2 className="text-5xl font-bold text-gray-800 mb-6">Top 5 Must-Visit Places</h2>
            <p className="text-xl text-gray-600">Iconic landmarks that define India's magnificent heritage</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
            {topAttractions.map((attraction, index) => (
              <Card
                key={index}
                className="text-center hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-4 bg-white/90 backdrop-blur-sm border-0 overflow-hidden group"
              >
                <div className="relative h-40 overflow-hidden">
                  <img
                    src={attraction.image || "/placeholder.svg"}
                    alt={attraction.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute top-4 left-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-orange-400 via-orange-500 to-orange-600 rounded-full flex items-center justify-center shadow-lg">
                      <span className="text-white text-xl font-bold">{index + 1}</span>
                    </div>
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="font-bold text-lg mb-3">{attraction.name}</h3>
                  <p className="text-gray-600 mb-3 flex items-center justify-center">
                    <MapPin className="h-4 w-4 mr-2 text-orange-500" />
                    {attraction.location}
                  </p>
                  <div className="flex items-center justify-center">
                    <Star className="h-5 w-5 text-yellow-400 fill-current" />
                    <span className="ml-2 text-lg font-semibold">{attraction.rating}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Enhanced Stats Section */}
      <section className="py-24 px-4 bg-gradient-to-r from-indigo-900 via-purple-900 to-pink-900 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <h2 className="text-5xl font-bold mb-6">India by Numbers</h2>
            <p className="text-xl opacity-90">Incredible facts about this diverse nation</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div className="group">
              <div className="w-24 h-24 bg-gradient-to-br from-orange-400 to-orange-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-2xl">
                <MapPin className="h-12 w-12 text-white" />
              </div>
              <h3 className="text-4xl font-bold mb-3">28</h3>
              <p className="text-xl opacity-90">States & Union Territories</p>
            </div>
            <div className="group">
              <div className="w-24 h-24 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-2xl">
                <Users className="h-12 w-12 text-white" />
              </div>
              <h3 className="text-4xl font-bold mb-3">1000+</h3>
              <p className="text-xl opacity-90">Languages Spoken</p>
            </div>
            <div className="group">
              <div className="w-24 h-24 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-2xl">
                <Calendar className="h-12 w-12 text-white" />
              </div>
              <h3 className="text-4xl font-bold mb-3">365</h3>
              <p className="text-xl opacity-90">Days of Festivals</p>
            </div>
            <div className="group">
              <div className="w-24 h-24 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-2xl">
                <Star className="h-12 w-12 text-white" />
              </div>
              <h3 className="text-4xl font-bold mb-3">40</h3>
              <p className="text-xl opacity-90">UNESCO World Heritage Sites</p>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced CTA Section */}
      <section className="py-24 px-4 bg-gradient-to-r from-orange-500 via-orange-600 to-green-500 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative max-w-4xl mx-auto text-center">
          <h2 className="text-5xl font-bold mb-8">Ready to Explore Incredible India?</h2>
          <p className="text-2xl mb-12 opacity-90 leading-relaxed">
            Start planning your journey through the most diverse and culturally rich country in the world
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Link href="/destinations">
              <Button
                size="lg"
                className="bg-white text-orange-600 hover:bg-gray-100 px-10 py-4 text-lg rounded-full shadow-2xl transform hover:scale-105 transition-all"
              >
                <Camera className="mr-2 h-5 w-5" />
                Browse Destinations
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="/plan-trip">
              <Button
                size="lg"
                variant="outline"
                className="border-2 border-white text-white hover:bg-white/20 bg-transparent px-10 py-4 text-lg rounded-full shadow-2xl transform hover:scale-105 transition-all"
              >
                <Calendar className="mr-2 h-5 w-5" />
                Plan Your Trip
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
