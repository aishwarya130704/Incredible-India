"use client"

import { useState } from "react"
import { Calendar, MapPin, Users, Star, Clock } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

const months = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
]

const festivals = {
  January: [
    {
      name: "Makar Sankranti",
      date: "14th January",
      region: "Pan India",
      description: "Harvest festival marking the transition of sun into Capricorn",
      significance: "Kite flying, sesame sweets, holy dips in rivers",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      name: "Pongal",
      date: "14-17th January",
      region: "Tamil Nadu",
      description: "Tamil harvest festival dedicated to Sun God",
      significance: "Rice cooking, cattle worship, traditional games",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      name: "Republic Day",
      date: "26th January",
      region: "Pan India",
      description: "National holiday celebrating the Constitution of India",
      significance: "Parades, flag hoisting, cultural programs",
      image: "/placeholder.svg?height=200&width=300",
    },
  ],
  February: [
    {
      name: "Vasant Panchami",
      date: "February (varies)",
      region: "North India",
      description: "Festival welcoming spring, dedicated to Goddess Saraswati",
      significance: "Yellow clothes, kite flying, worship of knowledge",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      name: "Maha Shivratri",
      date: "February/March (varies)",
      region: "Pan India",
      description: "Great night of Lord Shiva, fasting and prayers",
      significance: "Night-long vigil, temple visits, devotional songs",
      image: "/placeholder.svg?height=200&width=300",
    },
  ],
  March: [
    {
      name: "Holi",
      date: "March (varies)",
      region: "Pan India",
      description: "Festival of colors celebrating victory of good over evil",
      significance: "Color throwing, water balloons, festive foods",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      name: "Ugadi",
      date: "March/April (varies)",
      region: "Andhra Pradesh, Telangana",
      description: "Telugu New Year with traditional rituals",
      significance: "New year predictions, special dishes, decorations",
      image: "/placeholder.svg?height=200&width=300",
    },
  ],
  April: [
    {
      name: "Ram Navami",
      date: "April (varies)",
      region: "Pan India",
      description: "Birth anniversary of Lord Rama",
      significance: "Temple processions, devotional singing, fasting",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      name: "Baisakhi",
      date: "13th/14th April",
      region: "Punjab, North India",
      description: "Sikh New Year and harvest festival",
      significance: "Bhangra dancing, gurudwara visits, community feasts",
      image: "/placeholder.svg?height=200&width=300",
    },
  ],
  May: [
    {
      name: "Buddha Purnima",
      date: "May (varies)",
      region: "Pan India",
      description: "Birth anniversary of Gautama Buddha",
      significance: "Meditation, temple visits, charitable activities",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      name: "Rath Yatra",
      date: "June/July (varies)",
      region: "Odisha, Pan India",
      description: "Chariot festival of Lord Jagannath",
      significance: "Massive chariots, devotee processions, prasadam",
      image: "/placeholder.svg?height=200&width=300",
    },
  ],
  June: [
    {
      name: "Eid al-Fitr",
      date: "June (varies)",
      region: "Pan India",
      description: "Islamic festival marking end of Ramadan",
      significance: "Community prayers, feasting, charity, new clothes",
      image: "/placeholder.svg?height=200&width=300",
    },
  ],
  July: [
    {
      name: "Guru Purnima",
      date: "July (varies)",
      region: "Pan India",
      description: "Day dedicated to spiritual and academic teachers",
      significance: "Honoring gurus, spiritual discourses, gratitude",
      image: "/placeholder.svg?height=200&width=300",
    },
  ],
  August: [
    {
      name: "Independence Day",
      date: "15th August",
      region: "Pan India",
      description: "National holiday celebrating freedom from British rule",
      significance: "Flag hoisting, patriotic songs, cultural programs",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      name: "Raksha Bandhan",
      date: "August (varies)",
      region: "Pan India",
      description: "Festival celebrating brother-sister bond",
      significance: "Tying rakhi, gift exchange, family gatherings",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      name: "Krishna Janmashtami",
      date: "August/September (varies)",
      region: "Pan India",
      description: "Birth anniversary of Lord Krishna",
      significance: "Midnight celebrations, dahi handi, devotional songs",
      image: "/placeholder.svg?height=200&width=300",
    },
  ],
  September: [
    {
      name: "Ganesh Chaturthi",
      date: "August/September (varies)",
      region: "Maharashtra, Pan India",
      description: "Festival honoring Lord Ganesha",
      significance: "Clay idols, processions, immersion ceremonies",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      name: "Onam",
      date: "August/September (varies)",
      region: "Kerala",
      description: "Harvest festival and homecoming of King Mahabali",
      significance: "Pookalam, boat races, traditional feast",
      image: "/placeholder.svg?height=200&width=300",
    },
  ],
  October: [
    {
      name: "Navratri",
      date: "September/October (varies)",
      region: "Gujarat, Pan India",
      description: "Nine nights dedicated to Goddess Durga",
      significance: "Garba dancing, fasting, colorful celebrations",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      name: "Dussehra",
      date: "September/October (varies)",
      region: "Pan India",
      description: "Victory of good over evil, Lord Rama over Ravana",
      significance: "Ravana effigy burning, Ram Lila performances",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      name: "Gandhi Jayanti",
      date: "2nd October",
      region: "Pan India",
      description: "Birth anniversary of Mahatma Gandhi",
      significance: "Non-violence, peace prayers, cleanliness drives",
      image: "/placeholder.svg?height=200&width=300",
    },
  ],
  November: [
    {
      name: "Diwali",
      date: "October/November (varies)",
      region: "Pan India",
      description: "Festival of lights celebrating victory of light over darkness",
      significance: "Oil lamps, fireworks, sweets, family gatherings",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      name: "Bhai Dooj",
      date: "October/November (varies)",
      region: "Pan India",
      description: "Festival celebrating brother-sister love",
      significance: "Sister prayers for brother, gift exchange",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      name: "Guru Nanak Jayanti",
      date: "November (varies)",
      region: "Punjab, Pan India",
      description: "Birth anniversary of Guru Nanak",
      significance: "Gurudwara visits, processions, community service",
      image: "/placeholder.svg?height=200&width=300",
    },
  ],
  December: [
    {
      name: "Christmas",
      date: "25th December",
      region: "Pan India",
      description: "Birth of Jesus Christ, celebrated by Christians",
      significance: "Church services, carol singing, gift exchange",
      image: "/placeholder.svg?height=200&width=300",
    },
  ],
}

export default function FestivalsPage() {
  const [selectedMonth, setSelectedMonth] = useState("January")

  return (
    <div className="min-h-screen bg-gradient-to-b from-yellow-50 to-red-50 pt-20">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-gray-800 mb-4">Festivals & Culture</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Experience India's vibrant cultural tapestry through its colorful festivals celebrated throughout the year
          </p>
        </div>

        {/* Month Navigation */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">Festival Calendar</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {months.map((month) => (
              <Button
                key={month}
                variant={selectedMonth === month ? "default" : "outline"}
                onClick={() => setSelectedMonth(month)}
                className={`${
                  selectedMonth === month
                    ? "bg-orange-500 hover:bg-orange-600 text-white"
                    : "hover:bg-orange-50 hover:text-orange-600 hover:border-orange-300"
                } transition-all duration-200`}
              >
                <Calendar className="h-4 w-4 mr-2" />
                {month}
              </Button>
            ))}
          </div>
        </div>

        {/* Selected Month Festivals */}
        <div className="mb-8">
          <h3 className="text-3xl font-bold text-gray-800 mb-6 text-center">{selectedMonth} Festivals</h3>

          {festivals[selectedMonth] && festivals[selectedMonth].length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {festivals[selectedMonth].map((festival, index) => (
                <Card
                  key={index}
                  className="group hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border-0 bg-white/90 backdrop-blur-sm overflow-hidden"
                >
                  <div className="relative">
                    <img
                      src={festival.image || "/placeholder.svg"}
                      alt={festival.name}
                      className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    <div className="absolute top-4 right-4">
                      <Badge className="bg-orange-500 text-white">{festival.region}</Badge>
                    </div>
                    <div className="absolute bottom-4 left-4 text-white">
                      <h4 className="text-xl font-bold mb-1">{festival.name}</h4>
                      <p className="text-sm opacity-90 flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        {festival.date}
                      </p>
                    </div>
                  </div>

                  <CardContent className="p-6">
                    <p className="text-gray-600 mb-4 text-sm leading-relaxed">{festival.description}</p>

                    <div className="border-t pt-4">
                      <h5 className="font-semibold text-gray-800 mb-2 flex items-center">
                        <Star className="h-4 w-4 mr-1 text-orange-500" />
                        Celebrations
                      </h5>
                      <p className="text-sm text-gray-600">{festival.significance}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <Calendar className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-500 mb-2">No major festivals listed</h3>
              <p className="text-gray-400">Check other months for festival celebrations</p>
            </div>
          )}
        </div>

        {/* Cultural Highlights */}
        <Card className="border-0 bg-gradient-to-r from-orange-100 to-red-100 mb-8">
          <CardHeader>
            <CardTitle className="text-center text-2xl">Cultural Highlights of India</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 text-center">
              <div>
                <div className="w-16 h-16 bg-orange-500 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Users className="h-8 w-8 text-white" />
                </div>
                <h4 className="font-bold text-lg mb-2">Unity in Diversity</h4>
                <p className="text-sm text-gray-600">
                  Multiple religions, languages, and traditions coexisting harmoniously
                </p>
              </div>
              <div>
                <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Calendar className="h-8 w-8 text-white" />
                </div>
                <h4 className="font-bold text-lg mb-2">365 Days of Festivals</h4>
                <p className="text-sm text-gray-600">Every day is a celebration somewhere in India</p>
              </div>
              <div>
                <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-3">
                  <MapPin className="h-8 w-8 text-white" />
                </div>
                <h4 className="font-bold text-lg mb-2">Regional Variations</h4>
                <p className="text-sm text-gray-600">Each state has unique customs and celebrations</p>
              </div>
              <div>
                <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Star className="h-8 w-8 text-white" />
                </div>
                <h4 className="font-bold text-lg mb-2">Ancient Traditions</h4>
                <p className="text-sm text-gray-600">Thousands of years of cultural heritage</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Festival Tips */}
        <Card className="border-0 bg-white/90 backdrop-blur-sm">
          <CardHeader>
            <CardTitle>Festival Travel Tips</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h4 className="font-semibold mb-4 text-orange-600">Planning Your Visit</h4>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-orange-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    Book accommodations well in advance during major festivals
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-orange-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    Expect higher prices and larger crowds during festival seasons
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-orange-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    Research local customs and dress codes for religious festivals
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-orange-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    Join local celebrations for authentic cultural experiences
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-4 text-orange-600">Cultural Etiquette</h4>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-orange-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    Remove shoes before entering temples and homes
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-orange-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    Dress modestly, especially during religious celebrations
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-orange-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    Ask permission before photographing people or ceremonies
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-orange-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    Participate respectfully and follow local guidance
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
