"use client"

import { useState } from "react"
import { MapPin, DollarSign, Backpack, Clock, Star, CheckCircle } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

const sampleItineraries = [
  {
    id: 1,
    title: "7 Days Golden Triangle",
    duration: "7 Days",
    cities: ["Delhi", "Agra", "Jaipur"],
    budget: "₹25,000 - ₹40,000",
    difficulty: "Easy",
    highlights: ["Taj Mahal", "Red Fort", "Hawa Mahal", "Amber Fort"],
    image: "/placeholder.svg?height=200&width=300",
    itinerary: [
      { day: 1, city: "Delhi", activities: ["Arrive in Delhi", "Red Fort", "Jama Masjid", "Chandni Chowk"] },
      { day: 2, city: "Delhi", activities: ["India Gate", "Lotus Temple", "Qutub Minar", "Humayun's Tomb"] },
      { day: 3, city: "Agra", activities: ["Travel to Agra", "Taj Mahal at sunset", "Agra Fort"] },
      { day: 4, city: "Agra", activities: ["Taj Mahal at sunrise", "Mehtab Bagh", "Local markets"] },
      { day: 5, city: "Jaipur", activities: ["Travel to Jaipur", "City Palace", "Jantar Mantar"] },
      { day: 6, city: "Jaipur", activities: ["Amber Fort", "Hawa Mahal", "Local shopping"] },
      { day: 7, city: "Delhi", activities: ["Return to Delhi", "Departure"] },
    ],
  },
  {
    id: 2,
    title: "10 Days Kerala Backwaters",
    duration: "10 Days",
    cities: ["Kochi", "Munnar", "Thekkady", "Alleppey"],
    budget: "₹30,000 - ₹50,000",
    difficulty: "Moderate",
    highlights: ["Backwaters", "Tea Gardens", "Spice Plantations", "Ayurveda"],
    image: "/placeholder.svg?height=200&width=300",
    itinerary: [
      { day: 1, city: "Kochi", activities: ["Arrive in Kochi", "Fort Kochi", "Chinese Fishing Nets"] },
      { day: 2, city: "Kochi", activities: ["Mattancherry Palace", "Jewish Synagogue", "Spice Markets"] },
      { day: 3, city: "Munnar", activities: ["Travel to Munnar", "Tea Museum", "Tea Gardens"] },
      { day: 4, city: "Munnar", activities: ["Eravikulam National Park", "Top Station", "Echo Point"] },
      { day: 5, city: "Munnar", activities: ["Mattupetty Dam", "Kundala Lake", "Local sightseeing"] },
      { day: 6, city: "Thekkady", activities: ["Travel to Thekkady", "Periyar Wildlife Sanctuary"] },
      { day: 7, city: "Thekkady", activities: ["Spice Plantation Tour", "Bamboo Rafting"] },
      { day: 8, city: "Alleppey", activities: ["Travel to Alleppey", "Houseboat check-in"] },
      { day: 9, city: "Alleppey", activities: ["Backwater cruise", "Village visits", "Sunset views"] },
      { day: 10, city: "Kochi", activities: ["Return to Kochi", "Departure"] },
    ],
  },
  {
    id: 3,
    title: "14 Days Himachal Adventure",
    duration: "14 Days",
    cities: ["Shimla", "Manali", "Dharamshala", "Dalhousie"],
    budget: "₹35,000 - ₹60,000",
    difficulty: "Challenging",
    highlights: ["Mountain Views", "Adventure Sports", "Monasteries", "Hill Stations"],
    image: "/placeholder.svg?height=200&width=300",
    itinerary: [
      { day: 1, city: "Shimla", activities: ["Arrive in Shimla", "Mall Road", "Ridge"] },
      { day: 2, city: "Shimla", activities: ["Kufri", "Jakhoo Temple", "Christ Church"] },
      { day: 3, city: "Shimla", activities: ["Chail", "Local sightseeing"] },
      { day: 4, city: "Manali", activities: ["Travel to Manali", "Hadimba Temple"] },
      { day: 5, city: "Manali", activities: ["Solang Valley", "Adventure activities"] },
      { day: 6, city: "Manali", activities: ["Rohtang Pass (if open)", "Snow activities"] },
      { day: 7, city: "Manali", activities: ["Old Manali", "Manu Temple", "Local markets"] },
      { day: 8, city: "Dharamshala", activities: ["Travel to Dharamshala", "McLeod Ganj"] },
      { day: 9, city: "Dharamshala", activities: ["Dalai Lama Temple", "Bhagsu Waterfall"] },
      { day: 10, city: "Dharamshala", activities: ["Triund Trek", "Tibetan culture"] },
      { day: 11, city: "Dalhousie", activities: ["Travel to Dalhousie", "Local sightseeing"] },
      { day: 12, city: "Dalhousie", activities: ["Khajjiar", "Kalatop Wildlife Sanctuary"] },
      { day: 13, city: "Dalhousie", activities: ["Chamera Lake", "Local exploration"] },
      { day: 14, city: "Delhi", activities: ["Return journey", "Departure"] },
    ],
  },
]

const budgetTips = [
  {
    category: "Accommodation",
    budget: "Budget (₹500-1500/night)",
    options: ["Hostels", "Guesthouses", "Budget hotels", "Dormitories"],
    tips: ["Book in advance", "Check reviews", "Look for free breakfast"],
  },
  {
    category: "Accommodation",
    budget: "Mid-range (₹1500-4000/night)",
    options: ["3-star hotels", "Boutique stays", "Heritage hotels", "Homestays"],
    tips: ["Compare prices", "Check amenities", "Look for package deals"],
  },
  {
    category: "Food",
    budget: "Street Food (₹50-200/meal)",
    options: ["Local street vendors", "Dhabas", "Local restaurants"],
    tips: ["Choose busy stalls", "Drink bottled water", "Try local specialties"],
  },
  {
    category: "Food",
    budget: "Restaurants (₹300-800/meal)",
    options: ["Multi-cuisine restaurants", "Hotel restaurants", "Cafes"],
    tips: ["Check hygiene standards", "Ask for recommendations", "Try thali meals"],
  },
]

const packingList = [
  {
    category: "Clothing",
    items: [
      "Comfortable walking shoes",
      "Light cotton clothes",
      "Warm jacket",
      "Rain jacket",
      "Modest clothing for temples",
      "Sleepwear",
      "Undergarments",
    ],
  },
  {
    category: "Health & Hygiene",
    items: [
      "Sunscreen (SPF 30+)",
      "Insect repellent",
      "Hand sanitizer",
      "Personal medications",
      "First aid kit",
      "Toilet paper",
      "Wet wipes",
    ],
  },
  {
    category: "Electronics",
    items: ["Phone charger", "Power bank", "Universal adapter", "Camera", "Headphones", "Flashlight"],
  },
  {
    category: "Documents",
    items: [
      "Passport/ID proof",
      "Visa (if required)",
      "Travel insurance",
      "Hotel bookings",
      "Transport tickets",
      "Emergency contacts",
      "Photocopies of documents",
    ],
  },
  {
    category: "Miscellaneous",
    items: [
      "Backpack/daypack",
      "Water bottle",
      "Snacks",
      "Cash in small denominations",
      "Travel pillow",
      "Eye mask",
      "Earplugs",
    ],
  },
]

export default function PlanTripPage() {
  const [selectedItinerary, setSelectedItinerary] = useState(null)
  const [checkedItems, setCheckedItems] = useState({})

  const toggleCheck = (category, item) => {
    const key = `${category}-${item}`
    setCheckedItems((prev) => ({
      ...prev,
      [key]: !prev[key],
    }))
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-orange-50 pt-20">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-gray-800 mb-4">Plan Your Trip</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Everything you need to plan the perfect Indian adventure - from sample itineraries to packing lists
          </p>
        </div>

        <Tabs defaultValue="itineraries" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="itineraries">Sample Itineraries</TabsTrigger>
            <TabsTrigger value="budget">Budget Guide</TabsTrigger>
            <TabsTrigger value="packing">Packing Checklist</TabsTrigger>
          </TabsList>

          <TabsContent value="itineraries" className="space-y-8">
            {!selectedItinerary ? (
              <>
                <div className="text-center mb-8">
                  <h2 className="text-3xl font-bold text-gray-800 mb-4">Sample Itineraries</h2>
                  <p className="text-gray-600">
                    Choose from our carefully crafted itineraries for different regions and interests
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {sampleItineraries.map((itinerary) => (
                    <Card
                      key={itinerary.id}
                      className="hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 cursor-pointer border-0 bg-white/90 backdrop-blur-sm"
                    >
                      <div className="relative">
                        <img
                          src={itinerary.image || "/placeholder.svg"}
                          alt={itinerary.title}
                          className="w-full h-48 object-cover rounded-t-lg"
                        />
                        <div className="absolute top-4 right-4">
                          <Badge className="bg-purple-500 text-white">{itinerary.duration}</Badge>
                        </div>
                      </div>

                      <CardContent className="p-6">
                        <h3 className="text-xl font-bold mb-2">{itinerary.title}</h3>
                        <div className="space-y-2 mb-4">
                          <p className="text-sm text-gray-600 flex items-center">
                            <MapPin className="h-4 w-4 mr-1" />
                            {itinerary.cities.join(" → ")}
                          </p>
                          <p className="text-sm text-gray-600 flex items-center">
                            <DollarSign className="h-4 w-4 mr-1" />
                            {itinerary.budget}
                          </p>
                          <p className="text-sm text-gray-600 flex items-center">
                            <Star className="h-4 w-4 mr-1" />
                            {itinerary.difficulty}
                          </p>
                        </div>

                        <div className="mb-4">
                          <h4 className="font-semibold mb-2">Highlights</h4>
                          <div className="flex flex-wrap gap-1">
                            {itinerary.highlights.map((highlight, idx) => (
                              <Badge key={idx} variant="secondary" className="text-xs bg-orange-100 text-orange-700">
                                {highlight}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <Button
                          onClick={() => setSelectedItinerary(itinerary)}
                          className="w-full bg-purple-500 hover:bg-purple-600"
                        >
                          View Detailed Itinerary
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </>
            ) : (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-3xl font-bold text-gray-800">{selectedItinerary.title}</h2>
                  <Button variant="outline" onClick={() => setSelectedItinerary(null)} className="hover:bg-purple-50">
                    Back to Itineraries
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                  <Card className="text-center">
                    <CardContent className="p-4">
                      <Clock className="h-8 w-8 text-purple-500 mx-auto mb-2" />
                      <p className="font-semibold">{selectedItinerary.duration}</p>
                      <p className="text-sm text-gray-600">Duration</p>
                    </CardContent>
                  </Card>
                  <Card className="text-center">
                    <CardContent className="p-4">
                      <MapPin className="h-8 w-8 text-purple-500 mx-auto mb-2" />
                      <p className="font-semibold">{selectedItinerary.cities.length} Cities</p>
                      <p className="text-sm text-gray-600">Destinations</p>
                    </CardContent>
                  </Card>
                  <Card className="text-center">
                    <CardContent className="p-4">
                      <DollarSign className="h-8 w-8 text-purple-500 mx-auto mb-2" />
                      <p className="font-semibold">{selectedItinerary.budget}</p>
                      <p className="text-sm text-gray-600">Budget Range</p>
                    </CardContent>
                  </Card>
                  <Card className="text-center">
                    <CardContent className="p-4">
                      <Star className="h-8 w-8 text-purple-500 mx-auto mb-2" />
                      <p className="font-semibold">{selectedItinerary.difficulty}</p>
                      <p className="text-sm text-gray-600">Difficulty</p>
                    </CardContent>
                  </Card>
                </div>

                <Card>
                  <CardHeader>
                    <CardTitle>Day-by-Day Itinerary</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {selectedItinerary.itinerary.map((day, index) => (
                        <div key={index} className="border-l-4 border-purple-500 pl-6 pb-4">
                          <div className="flex items-center mb-2">
                            <div className="w-8 h-8 bg-purple-500 text-white rounded-full flex items-center justify-center text-sm font-bold mr-3">
                              {day.day}
                            </div>
                            <h4 className="font-semibold text-lg">{day.city}</h4>
                          </div>
                          <ul className="space-y-1">
                            {day.activities.map((activity, idx) => (
                              <li key={idx} className="text-gray-600 flex items-center">
                                <div className="w-2 h-2 bg-purple-300 rounded-full mr-2"></div>
                                {activity}
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          <TabsContent value="budget" className="space-y-8">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-800 mb-4">Budget Planning Guide</h2>
              <p className="text-gray-600">Plan your expenses with our comprehensive budget breakdown</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {budgetTips.map((section, index) => (
                <Card key={index} className="border-0 bg-white/90 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <DollarSign className="h-5 w-5 mr-2 text-green-500" />
                      {section.category} - {section.budget}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">Options</h4>
                      <div className="flex flex-wrap gap-2">
                        {section.options.map((option, idx) => (
                          <Badge key={idx} variant="secondary" className="bg-green-100 text-green-700">
                            {option}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Tips</h4>
                      <ul className="space-y-1">
                        {section.tips.map((tip, idx) => (
                          <li key={idx} className="text-sm text-gray-600 flex items-center">
                            <CheckCircle className="h-3 w-3 mr-2 text-green-500" />
                            {tip}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card className="border-0 bg-gradient-to-r from-green-100 to-blue-100">
              <CardHeader>
                <CardTitle>Daily Budget Estimates</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-3">
                      <DollarSign className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-800">₹1,000-2,000</h3>
                    <p className="text-gray-600">Budget Traveler</p>
                    <p className="text-sm text-gray-500 mt-2">Hostels, street food, public transport</p>
                  </div>
                  <div className="text-center">
                    <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-3">
                      <DollarSign className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-800">₹3,000-5,000</h3>
                    <p className="text-gray-600">Mid-Range Traveler</p>
                    <p className="text-sm text-gray-500 mt-2">Hotels, restaurants, private transport</p>
                  </div>
                  <div className="text-center">
                    <div className="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-3">
                      <DollarSign className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-800">₹8,000+</h3>
                    <p className="text-gray-600">Luxury Traveler</p>
                    <p className="text-sm text-gray-500 mt-2">5-star hotels, fine dining, premium services</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="packing" className="space-y-8">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-800 mb-4">Packing Checklist</h2>
              <p className="text-gray-600">Don't forget the essentials for your Indian adventure</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {packingList.map((category, index) => (
                <Card key={index} className="border-0 bg-white/90 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Backpack className="h-5 w-5 mr-2 text-orange-500" />
                      {category.category}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {category.items.map((item, idx) => {
                        const key = `${category.category}-${item}`
                        const isChecked = checkedItems[key]
                        return (
                          <div
                            key={idx}
                            className={`flex items-center p-2 rounded cursor-pointer transition-colors ${
                              isChecked ? "bg-green-50 text-green-700" : "hover:bg-gray-50"
                            }`}
                            onClick={() => toggleCheck(category.category, item)}
                          >
                            <div
                              className={`w-5 h-5 rounded border-2 mr-3 flex items-center justify-center ${
                                isChecked ? "bg-green-500 border-green-500" : "border-gray-300"
                              }`}
                            >
                              {isChecked && <CheckCircle className="h-3 w-3 text-white" />}
                            </div>
                            <span className={isChecked ? "line-through" : ""}>{item}</span>
                          </div>
                        )
                      })}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card className="border-0 bg-gradient-to-r from-orange-100 to-red-100">
              <CardHeader>
                <CardTitle>Packing Tips for India</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold mb-3">Climate Considerations</h4>
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li>• Pack light, breathable fabrics</li>
                      <li>• Bring layers for air-conditioned spaces</li>
                      <li>• Waterproof items for monsoon season</li>
                      <li>• Sun protection is essential</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-3">Cultural Sensitivity</h4>
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li>• Modest clothing for religious sites</li>
                      <li>• Remove shoes when entering temples</li>
                      <li>• Carry a scarf for covering head/shoulders</li>
                      <li>• Avoid leather items in some temples</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
