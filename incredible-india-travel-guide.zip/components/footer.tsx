"use client"

import Link from "next/link"
import { MapPin, Phone, Mail, Heart } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-gradient-to-r from-orange-800 to-green-800 text-white">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center">
                <MapPin className="h-5 w-5 text-orange-600" />
              </div>
              <span className="text-xl font-bold">Incredible India</span>
            </div>
            <p className="text-orange-100 text-sm leading-relaxed">
              Your ultimate travel companion to explore the incredible diversity, rich culture, and magnificent heritage
              of India.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/destinations" className="text-orange-100 hover:text-white transition-colors text-sm">
                  Destinations
                </Link>
              </li>
              <li>
                <Link href="/transport" className="text-orange-100 hover:text-white transition-colors text-sm">
                  Transport Guide
                </Link>
              </li>
              <li>
                <Link href="/plan-trip" className="text-orange-100 hover:text-white transition-colors text-sm">
                  Plan Your Trip
                </Link>
              </li>
              <li>
                <Link href="/festivals" className="text-orange-100 hover:text-white transition-colors text-sm">
                  Festivals & Culture
                </Link>
              </li>
            </ul>
          </div>

          {/* Travel Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Travel Info</h3>
            <ul className="space-y-2 text-sm text-orange-100">
              <li>• Best Time to Visit: Oct-Mar</li>
              <li>• Currency: Indian Rupee (₹)</li>
              <li>• Languages: Hindi, English + 22 others</li>
              <li>• Time Zone: IST (UTC+5:30)</li>
              <li>• Emergency: 100 (Police)</li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Emergency Contacts</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-2 text-sm">
                <Phone className="h-4 w-4 text-orange-300" />
                <span className="text-orange-100">Tourist Helpline: 1363</span>
              </div>
              <div className="flex items-center space-x-2 text-sm">
                <Phone className="h-4 w-4 text-orange-300" />
                <span className="text-orange-100">Police: 100</span>
              </div>
              <div className="flex items-center space-x-2 text-sm">
                <Mail className="h-4 w-4 text-orange-300" />
                <span className="text-orange-100">info@incredibleindia.gov</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-orange-700 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-orange-200 text-sm">
            © 2024 Incredible India Travel Guide. Made with <Heart className="h-4 w-4 inline text-red-400" /> for
            travelers.
          </p>
          <p className="text-orange-200 text-sm mt-2 md:mt-0">
            Explore Responsibly • Travel Sustainably • Respect Local Culture
          </p>
        </div>
      </div>
    </footer>
  )
}
